//derive-union-type-from-tuple-array-values
const list = ['a', 'b', 'c'] as const;
type NeededUnionType = typeof list[number]; // 'a'|'b'|'c';