//https://stackoverflow.com/questions/41385059/possible-to-extend-types-in-typescript
type MyEvent = {
    name: string;
    dateCreated: string;
    type: string;
}

type UserEvent = MyEvent & { UserId: string }

interface UserEvent2 extends MyEvent {
    UserId: string;
}



type TypeA = {
    nameA: string;
};
type TypeB = {
    nameB: string;
};
export type TypeC = TypeA & TypeB;

const some: TypeC = {
    nameB: 'B',
    nameA: 'A',
};
