/*
overload an entire interface based on the type of a generic type
https://stackoverflow.com/questions/69803002/is-it-possible-to-overload-an-entire-interface-based-on-the-type-of-a-generic-ty/69803052#69803052
You can't do this with generic interface declarations, but you can use conditional types to accomplish the same behavior
*/
type Foo<T> =
    T extends string ? {
        foo(): void;
        bar(): void;
    } :
    T extends number ? {
        bar(): void;
    } :
    {}

/*
interface Foo<string> {
    foo(): void
    bar(): void
}

interface Foo<number> {
    bar(): void
}
*/
f : Foo<string>; 

f2 : Foo<number>;