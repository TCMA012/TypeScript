/*
class constructor argument type change based on input
https://stackoverflow.com/questions/75721314/typescript-class-constructor-argument-type-change-based-on-input/75721335#75721335

mix the discriminated union with an intersection type to avoid duplicating common properties
*/
type BuilderConfig = {
  // Common part
  id: string;
} & ({
  // Script part
  type: "script";
  script: string;
} | {
  // Docker part
  type: "docker"
  dockerfile: string;
})

class Builder {
    constructor(private config: BuilderConfig) {}
}
  
new Builder({ 
    id: "test", 
    type: "docker", 
    dockerfile: "./Dockerfile",  // `dockerfile` is required but `script` does not appear as an option in intellisense
});
  
new Builder({
    id: "test",
    type: "script",
    script: "ls -la",  // `script` is required but `dockerfile` does not appear as an option in intellisense
});