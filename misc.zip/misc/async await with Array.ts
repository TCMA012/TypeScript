//async await with Array.map
let arr0 = [1, 2, 3, 4, 5];

let results: number[] = await Promise.all(arr0.map(async (item): Promise<number> => {
    await callAsynchronousOperation(item);
    return item + 1;
}));