//https://stackoverflow.com/questions/37265275/how-to-implement-class-constants
class MyClass {
    static readonly myReadOnlyProperty = 1;

    constructor() {
        MyClass.myReadOnlyProperty = 5; // error, readonly
    }

    myMethod() {
        console.log(MyClass.myReadOnlyProperty);
        MyClass.myReadOnlyProperty = 5; // error, readonly
    }

    get MY_CONSTANT():number {return 10};
    get MY_CONSTANT2() {return 100};
}

MyClass.myReadOnlyProperty = 5; // error, readonly
new MyClass().MY_CONSTANT;
new MyClass().MY_CONSTANT2;



const MY_CONSTANT3: string = "wazzup";

export class MyClass2 {

    public myFunction() {
        alert(MY_CONSTANT3);
    }
}