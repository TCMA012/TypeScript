/*
Accessing Nested Variant in Type Definition
https://stackoverflow.com/questions/69920803/accessing-nested-variant-in-type-definition
*/
type Events = 'DATA' | 'ABC' | 'DEF'

type PayloadMap = {
    DATA: { x: number }
    ABC: { y: string }
    DEF: null
}

export type Handlers<E extends string, P extends Record<E, any>> = { 
    [event in E]?:  (payload: P[event]) => any
} 

const handlers: Handlers<Events, PayloadMap> = {
    DATA: (payload) => {
        const { x } = payload;
        console.log(x)
        return null
    }
}