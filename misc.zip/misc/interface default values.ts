/*
interface default values
cannot provide default values for interfaces or type aliases as they are compile time only and 
default values need runtime support

But values that are not specified default to undefined in JavaScript runtimes. 
So you can mark them as optional:



can't set default values in an interface, but 
use optional properties:
*/
interface IX {
  a: string,
  b?: any,
  c?: number
}
// when you create it you only need to provide a:
let x: IX = {
    a: 'abc'
};
//can provide the values as needed:
x.a = 'xyz'
x.b = 123
x.c = 1




type OptionalKeys<T> = { [K in keyof T]-?: {} extends Pick<T, K> ? K : never }[keyof T];
type Defaults<T> = Required<Pick<T, OptionalKeys<T>>>

const defaults: Defaults<IX> = {
    b: null,
    c: 1
};

export class MyClass {
    // all options in class must have values
    options: Required<IX>;

    constructor(options: IX) {
        // merge passed options and defaults
        this.options = Object.assign({}, defaults, options);
    }
}


const myClass0 = new MyClass({
    a: 'hi'
});
console.log(myClass0.options);
//{"a": "hi","b": null,"c": 1} 

const myClass = new MyClass({
    a: 'hello',
    b: true,
});
console.log(myClass.options);
// { a: 'hello', b: true, c: 1 }



/*
Define an option interface as well as an according constant containing the defaults; 
in the constructor use the spread operator to set the options member variable
*/
interface IXOptions {
    a?: string,
    b?: any,
    c?: number
}

const XDefaults: IXOptions = {
    a: "default",
    b: null,
    c: 1
}

export class ClassX {
    private options: IXOptions;

    constructor(XOptions: IXOptions) {
        this.options = { ...XDefaults, ...XOptions };
    }

    public printOptions(): void {
        console.log(this.options.a);
        console.log(this.options.b);
        console.log(this.options.c);
    }
}

const x2 = new ClassX({ a: "set" });
x2.printOptions();
/*
set
null
1
*/



//implement the interface with a class, then you can deal with initializing the members in the constructor:
class IXClass implements IX {
    a: string;
    b: any;
    c: number;

    constructor(obj: IX);
    constructor(a: string, b: any, c: number);
    constructor() {
        if (arguments.length == 1) {
            this.a = arguments[0].a;
            this.b = arguments[0].b;
            this.c = arguments[0].c;
        } else {
            this.a = arguments[0];
            this.b = arguments[1];
            this.c = arguments[2];
        }
    }
}
//Another approach is to use a factory function:
function ixFactory(a: string, b: any, c: number): IX {
    return {
        a: a,
        b: b,
        c: c
    }
}
var ix2: IX = {};

ix2 = new IXClass({a: 'string', b: 2, c: 1});
// or
ix2 = ixFactory('string', 2, 1);





/*
Partial changes the type. x no longer implements IX, but a partial of IX. 
Partial is good for places where every property might be optional, 
for example with an ORM, where you can pass a partial of an object interface and 
update only the fields that are defined (as opposed to undefined which is what every field of a Partial can be). 
For interfaces that have fields with default values, you can declare object literals implementing those type of interfaces, 
without having to declare the default values, using the 
let x: Partial<IX> = { / * non-default fields * / } as IX syntax.
*/
let partial: Partial<IX> = {
    a: 'abc'
}