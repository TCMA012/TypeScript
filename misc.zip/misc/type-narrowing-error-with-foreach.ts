/*
https://stackoverflow.com/questions/63223715/typescript-type-narrowing-error-with-foreach
https://herringtondarkholme.github.io/2017/02/04/flow-sensitive/
https://stackoverflow.com/questions/75038004/props-items-object-is-possibly-undefined-after-return-early-condition/75075873#75075873
https://github.com/Microsoft/TypeScript/issues/9998
https://exploringjs.com/tackling-ts/ch_type-guards-assertion-functions.html
it does in general not know when the callback is executed, so the narrowing may not be valid any longer.

Callbacks may be executed much later (think of asynchronous code), which is why TypeScript undoes narrowing inside callbacks.
*/
type SomeItem = {offer_id: string};
interface Props {
    item?: SomeItem;
}

export const Element = (props: Props) => {
    if (props.item === undefined) {
        return null;
    }

    const offer = offers.find((offer) => offer.id === props.item.offer_id);

    return <div>{ props.item.getPayoutPlaceholder() } < /div>; 
};



/*
props.item.offer_id is in a callback, and so 
TS cannot be sure that props.item has not changed between the time you check it and the time the callback is called.
As you noted, you could get around it by defining a constant variable:
*/
const item = props.item;
//It should also be noted that destructuring also works:
export const Element = ({ item }: Props) => {}
//but notice that changing const to let makes the original error surface again:
let item = props.item;
// that's because now TS is not sure that it hasn't changed, like before (since let is mutable and can be reassigned).