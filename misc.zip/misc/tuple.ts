//https://blog.logrocket.com/exploring-use-cases-typescript-tuples/
type MyNamedTuple = [name: string, age: number, isAdmin: boolean];
const person: MyNamedTuple = ['John Doe', 30, false];

type MyTuple = [number, string, boolean];
const myTuple: MyTuple = [10, "Hello", true];
for (const element of myTuple) {
  console.log(element);
}


const mappedTuple: MyTuple = myTuple.map((element) => element * 2);
console.log(mappedTuple); // Output: [20, "HelloHello", NaN]

const filteredTuple: MyTuple = myTuple.filter((element) => typeof element === "string");
console.log(filteredTuple); // Output: [NaN, "Hello", NaN]

const reducedValue: number = myTuple.reduce((acc, curr) => acc + (typeof curr === "number" ? curr : 0), 0);
console.log(reducedValue); // Output: 10