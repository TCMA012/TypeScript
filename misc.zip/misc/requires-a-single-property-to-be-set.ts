/*
https://stackoverflow.com/questions/48230773/how-to-create-a-partial-like-that-requires-a-single-property-to-be-set

takes a type T and produces a related type which contains at least one property from T.
it's like Partial<T> but excludes the empty object.
*/
type AtLeastOne<T, U = {[K in keyof T]: Pick<T, K> }> = Partial<T> & U[keyof U]
/*
To dissect it: first of all, 
AtLeastOne<T> is Partial<T> intersected with something. 
U[keyof U] means that it's the union of all property values of U. 
(the default value of) U is a mapped type where each property of T is mapped to Pick<T, K>, 
a single-property type for the key K. 
(e.g. Pick<{foo: string, bar: number},'foo'> is equivalent to {foo: string}... 
it "picks" the 'foo' property from the original type.) 
U[keyof U] in this case is the union of all possible single-property types from T.

Let's see step-by-step how it operates on the following concrete type:
*/
type FullLinkRestSource = {
  model: string;
  rel: string;
  title: string;
}

type LinkRestSource = AtLeastOne<FullLinkRestSource>
//That expands to

type LinkRestSource1 = AtLeastOne<FullLinkRestSource, {
  [K in keyof FullLinkRestSource]: Pick<FullLinkRestSource, K>
}>
//or

type LinkRestSource2 = AtLeastOne<FullLinkRestSource, {
  model: Pick<FullLinkRestSource, 'model'>,
  rel: Pick<FullLinkRestSource, 'rel'>,
  title: Pick<FullLinkRestSource, 'title'>
}>
//or

type LinkRestSource3 = AtLeastOne<FullLinkRestSource, {
  model: {model: string},
  rel: {rel: string},
  title: {title: string}
}>
//or

type LinkRestSource4 = Partial<FullLinkRestSource> & {
  model: {model: string},
  rel: {rel: string},
  title: {title: string}
}[keyof {
  model: {model: string},
  rel: {rel: string},
  title: {title: string}
}]
//or

type LinkRestSource5 = Partial<FullLinkRestSource> & {
  model: {model: string},
  rel: {rel: string},
  title: {title: string}
}['model' | 'rel' | 'title']
//or

type LinkRestSource6 = Partial<FullLinkRestSource> &
  ({model: string} | {rel: string} | {title: string})
//or

type LinkRestSource7 = {model?: string, rel?: string, title?: string} & 
  ({model: string} | {rel: string} | {title: string})
//or

type LinkRestSource8 = { model: string, rel?: string, title?: string } 
  | {model?: string, rel: string, title?: string} 
  | {model?: string, rel?: string, title: string}


const okay0: LinkRestSource = { model: 'a', rel: 'b', title: 'c' }
const okay1: LinkRestSource = { model: 'a', rel: 'b' }
const okay2: LinkRestSource = { model: 'a' }
const okay3: LinkRestSource = { rel: 'b' }
const okay4: LinkRestSource = { title: 'c' }

const error0: LinkRestSource = {} // missing property
const error1: LinkRestSource = { model: 'a', titel: 'c' } // excess property on string literal

/*
I found that it doesn't enforce types that have optional parameters, but found a fix by 
splitting the implementation into two types: 
*/
type AtLeastOne2<T> = Partial<T> & U<Required<T>>[keyof U<T>] and type U<T> = {[K in keyof T]: Pick<T, K>}

//doesn't work when one of the properties are optional. This worked when wrapping with Required utility type 
type AtLeastOne3<T extends Record<string, any>> = keyof T extends infer K ? K extends string ? Pick<Required<T>, K & keyof T> & Partial<T> : never : never; – 

//this does not work when one or all of the properties is optional: 
type AtLeastOne4<T, U = { [K in keyof Required<T>]: Pick<Required<T>, K> }> = Partial<T> & U[keyof U]; 
//The only change to your solution is that instead of picking from T, we pick the keys and values from Required<T>.



/*
Partial<T> & is not needed because of how TS handles unions of objects with different fields. – 


it depends on the use case; 
the question as asked seems to want to constrain the missing properties to undefined which 
is not guaranteed if you leave out Partial<T> completely; 
*/



//if you know which properties you want
type AtLeast<T, K extends keyof T> = Partial<T> & Pick<T, K>
//This would also allow you to lock in multiple keys of a type, e.g.
type LinkRestSource9<T> = AtLeast<T, 'model' | 'rel'>




type AtLeastTwo<T, U = { [K in keyof T]: Pick<T, K> & AtLeastOne<Omit<T, K>> }> = Partial<T> & U[keyof U]





type X<A, B, C> = (A & Partial<B> & Partial<C>) | (Partial<A> & B & Partial<C>) | (Partial<A> & Partial<B> & C);
type LinkRestSource10 = X<{ model: string }, { rel: string }, { title: string }>
var d: LinkRestSource10 = {rel: 'sdf'};



export interface MainData {
    name: string;
    CRF: string;
    email?: string;
    cellphone?: string;
    facebookId?: string;
}
/*
...and if you only need at least one between 'email', 'cellphone' and 'facebookId', 
change and merge interfaces without optional symbol for every propoerty:
*/
export interface registByEmail extends Omit<MainData, 'email'> { email: string }
export interface registByCellphone extends Omit<MainData, 'cellphone'> { cellphone: string }
export interface registByFacebook extends Omit<MainData, 'facebookId'> { facebookId: string }

export type RegistData = registByCellphone | registByEmail | registByFacebook

// error
let clienterror: RegistData = { name, CRF }
// its ok
let client0: RegistData = { name, CRF, email }
let client1: RegistData = { name, CRF, cellphone }
let client2: RegistData = { name, CRF, facebookId }
let client3: RegistData = { name, CRF, email, cellphone }
