type Nullable<T> = T | null;
type Nullable2<T> = T | null | undefined;

var foo: Nullable<number> = 10; // ok
var baz: Nullable<number> = null; // ok
var bar: Nullable<number> = true; // type 'true' is not assignable to type 'Nullable<number>'

var arr1: Nullable<Array<number>> = [1,2]; // ok
var obj2: Nullable<Object> = {}; // ok

 // Type 'number[]' is not assignable to type 'string[]'. 
 // Type 'number' is not assignable to type 'string'
var arr2: Nullable<Array<string>> = [1,2];



interface Employee{
   id: number;
   name: string;
   salary: Nullable<number>;
}

let employe1: Employee = { id: 1, name: 'John', salary: 100 };
let employe2: Employee = { id: 1, name: 'John', salary: null };