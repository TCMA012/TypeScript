/*
https://stackoverflow.com/questions/13212625/typescript-function-overloading
function overloading
When you overload in TypeScript, 
you only have one implementation with multiple signatures.
Only the three overloads are recognized by TypeScript as possible signatures for a method call, not the actual implementation. 
The implementation signature must be compatible with all the overloads.
*/
class Foofunctionoverload {
    myMethod(a: string);
    myMethod(a: number);
    myMethod(a: number, b: string);
    myMethod(a: string | number, b?: string) {
        alert(a.toString());
    }
}



//You can declare an overloaded function by declaring the function as having a type which has multiple invocation signatures:
interface IFoo
{
    bar: {
        (s: string): number;
        (n: number): string;
    }
}

var foo1: IFoo = {
    bar: {
        /*
        (s: 's'): 10,
        (n: 2): "string"
        */
        /*
        's': 10,
        (n: 2): "string"
        */
    }
};

var n: number = foo1.bar('baz');     // OK
var s: string = foo1.bar(123);       // OK
var a: number[] = foo1.bar([1,2,3]); // ERROR
/*
The actual definition of the function must be singular and perform the appropriate dispatching internally on its arguments.

For example, using a class (which could implement IFoo, but doesn't have to):
the any form is hidden by the more specifically typed overrides.
*/
class Foo2
{
    public bar(s: string): number;
    public bar(n: number): string;
    public bar(arg: any): any 
    {
        if (typeof(arg) === 'number')
            return arg.toString();
        if (typeof(arg) === 'string')
            return arg.length;
    }
}

var foo2: new Foo2();

var n: number = foo2.bar('baz');     // OK
var s: string = foo2.bar(123);       // OK
var a: number[] = foo2.bar([1,2,3]); // ERROR







//Overloads are a compile-time construct with no impact on the JS runtime:

function foo(s: string): string // overload #1 of foo
function foo(s: string, n: number): number // overload #2 of foo
function foo(s: string, n?: number): string | number {/* ... */
    return 'str'} // foo implementation
/*
A duplicate implementation error is triggered, if you use above code (safer than JS). 
TS chooses the first fitting overload in top-down order, so overloads are sorted from most specific to most broad.

Method overloading in TS: a more complex example
Overloaded class method types can be used in a similar way to function overloading:
*/
class LayerFactory {
    createFeatureLayer(a1: string, a2: number): string
    createFeatureLayer(a1: number, a2: boolean, a3: string): number
    createFeatureLayer(a1: string | number, a2: number | boolean, a3?: string)
        : number | string { /*... your implementation*/ return 'str'}
}

const fact = new LayerFactory()
fact.createFeatureLayer("foo", 42) // string
fact.createFeatureLayer(3, true, "bar") // number
/*
The vastly different overloads are possible, 
as the function implementation is compatible to all overload signatures - enforced by the compiler.
*/