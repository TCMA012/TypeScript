/*
Regex-validated string types
regex-matched string type
https://github.com/microsoft/TypeScript/issues/41160
*/
type MarkerTime =`${number| ''}${number}:${number}${number}`

let a: MarkerTime = "0-00" // error
let b: MarkerTime = "0:00" // ok
let c: MarkerTime = "09:00" // ok



//avoid matching "93.242:942.23"
type SingleNumber = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;  
type MarkerTime2 =`${SingleNumber| ''}${SingleNumber}:${SingleNumber}${SingleNumber}`;
let a2: MarkerTime2 = "93.242:942.23" // error



/*
model a time restricted string type called Time. 
Time expects strings in the format hh:mm (e.g. "23:59") here for simplification.
This solution has 2039 enum members for the Time type.
*/
type D1 = 0|1;
type D3 = D1|2|3;
type D5 = D3|4|5;
type D9 = D5|6|7|8|9;

type Hours = `${D9}` | `${D1}${D9}` | `2${D3}`;
type Minutes = `${D5}${D9}`;
type Time = `${Hours}:${Minutes}`;

const validTimes: Time[] = ["00:00","01:30", "23:59", "16:30"]
const invalidTimes: Time[] = ["29:00", "30:00", "23:60", "0:61"] // all emit error



type HourPrefix = '0'|'1'|'2';
type MinutePrefix = HourPrefix | '3'|'4'|'5';
type Digit = MinutePrefix |'6'|'7'|'8'|'9';

type Time1 = `${HourPrefix | ''}${Digit}:${MinutePrefix}${Digit}`

const validTimes1: Time1[] = ["00:00","01:30", "23:59", "16:30"]
const invalidTimes1: Time1[] = ["29:00", "30:00", "23:60", "0:61"] // emit error. not 100% correct


/*
define HH and MM types
Paste following code into your browser web console:
*/
Array.from({length:24},(v,i)=> i).reduce((acc,cur)=> `${acc}${cur === 0 ? "" : "|"}'${String(cur).padStart(2, '0')}'`, "type HH = ")
Array.from({length:60},(v,i)=> i).reduce((acc,cur)=> `${acc}${cur === 0 ? "" : "|"}'${String(cur).padStart(2, '0')}'`, "type MM = ")

/*
type HH = '00'|'01'|'02'|'03'|'04'|'05'|'06'|'07'|...|'22'|'23'
type MM = '00'|'01'|'02'|'03'|'04'|'05'|'06'|'07'|...|'58'|'59'
*/
type MM = '00'|'01'|'02'|'03'|'04'|'05'|'06'|'07'|'08'|'09'|'10'|'11'|'12'|'13'|'14'|'15'|'16'|'17'|'18'|'19'|'20'|'21'|'22'|'23'|'24'|'25'|'26'|'27'|'28'|'29'|'30'|'31'|'32'|'33'|'34'|'35'|'36'|'37'|'38'|'39'|'40'|'41'|'42'|'43'|'44'|'45'|'46'|'47'|'48'|'49'|'50'|'51'|'52'|'53'|'54'|'55'|'56'|'57'|'58'|'59'
type HH = '00'|'01'|'02'|'03'|'04'|'05'|'06'|'07'|'08'|'09'|'10'|'11'|'12'|'13'|'14'|'15'|'16'|'17'|'18'|'19'|'20'|'21'|'22'|'23'

type Time2 = `${HH}:${MM}`

const validTimes2: Time2[] = ["00:00","01:30", "23:59", "16:30"]
const invalidTimes2: Time2[] = ["29:00", "30:00", "23:60", "0:61"] // all emit error




//use const assertions for the type construction
const hours = [
  '00' , '01', '02', '03', '04', '05', '06', '07', '08',
  '09' , '10', '11', '12', '13', '14', '15', '16', 
  '17' , '18', '19', '20', '21', '22', '23'
] as const

type HH3 = typeof hours[number]

const minutes = [
  '00', '01', '02', '03', '04', '05', '06', '07', '08', '09', 
  '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', 
  '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', 
  '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', 
  '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', 
  '50', '51', '52', '53', '54', '55', '56', '57', '58', '59'
] as const 

type MM3 = typeof minutes[number]

type Time3 = `${HH}:${MM}`

const validTimes3: Time3[] = ["00:00","01:30", "23:59", "16:30"]
const invalidTimes3: Time3[] = ["29:00", "30:00", "23:60", "0:61"] // all emit error



type HexChar = '0' | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | 'a' | 'A' | 'b' | 'B' | 'c' | 'C' | 'd' | 'D' | 'e' | 'E' | 'f' | 'F'