//the-time-between-2-dates
let time = new Date().getTime() - new Date("2013-02-20T12:01:04.753Z").getTime();
(new Date()).valueOf() - (new Date("2013-02-20T12:01:04.753Z")).valueOf()