//define-type-of-async-function
interface SearchFn0 {
    (subString: string): Promise<boolean>;
}

//or as a type declaration - recommend
type SearchFn = (subString: string) => Promise<boolean>;



//Pass the type of the returned object to the Promise generic.

type SearchFn2 = (subString: string): Promise<string>;
//Alternatively you can declare an AsyncFunction generic type.

/*
type AsyncFunction <A,O> = (...args:A) => Promise<O> 
type SearchFn3 = AsyncFunction<[string], string>
//AsyncFunction is a type generic that receives two type variables - the type of the input(A), and the type of the output.
*/