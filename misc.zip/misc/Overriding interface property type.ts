/*
Overriding interface property type defined in Typescript d.ts file
An interface in x.d.ts is defined as

interface A {
  property: number;
}
I want to change it in the typescript files that I write to

interface A {
  property: Object;
}
or even this would work

interface B extends A {
  property: Object;
}
*/



//Exclude property from type
interface A {
    x: string
}

export type B = Omit<A, 'x'> & { x: number };

interface B2 extends Omit<A, 'x'> {
  x: number
}



type Modify<T, R> = Omit<T, keyof R> & R;

type ModifiedType = Modify<OriginalType, {
    a: number;
    b: number;
}>

interface ModifiedInterface extends Modify<OriginalType, {
    a: number;
    b: number;
}> { }

interface OriginalInterface {
    a: string;
    b: boolean;
    c: number;
}

type ModifiedInterface2 = Modify<OriginalInterface, {
    a: number;
    b: number;
}>

type OriginalType = {
    a: string;
    b: boolean;
    c: number;
}

// ModifiedType = { a: number; b: number; c: number; }

type R0 = Omit<OriginalType, 'a' | 'b'>       // { c: number; }
type R1 = R0 & { a: number, b: number }       // { a: number; b: number; c: number; }

type T0 = Exclude<'a' | 'b' | 'c', 'a' | 'b'> // 'c'
type T1 = Pick<OriginalType, T0>              // { c: number; }
type T2 = T1 & { a: number, b: number }       // { a: number; b: number; c: number;



type ModifiedType2 = ModifyDeep<Original, Overrides>
interface ModifiedInterface extends ModifyDeep<Original, Overrides> {}
{
const example: ModifiedType = {
  a: {
    a: { a: number },
    b: number,
    c: number,
    d: string,
    e: number,
  }
}
}

type ModifyDeep<A, B extends DeepPartialAny<A>> = {
    [K in keyof A | keyof B]:          // For all keys in A and B:
    K extends keyof A                // ───┐
    ? K extends keyof B            // ───┼─ key K exists in both A and B
    ? A[K] extends AnyObject     //    │  ┴──┐
    ? B[K] extends AnyObject   //    │  ───┼─ both A and B are objects
    ? ModifyDeep<A[K], B[K]> //    │     │  └─── We need to go deeper (recursively)
    : B[K]                   //    │     ├─ B is a primitive 🠆 use B as the final type (new type)
    : B[K]                     //    │     └─ A is a primitive 🠆 use B as the final type (new type)  
    : A[K]                       //    ├─ key only exists in A 🠆 use A as the final type (original type)   
    : B[K]                         //    └─ key only exists in B 🠆 use B as the final type (new type)
}

type AnyObject = Record<string, any>

// This type is here only for some intellisense for the overrides object
type DeepPartialAny<T> = {
    /** Makes each property optional and turns each leaf property into any, allowing for type overrides by narrowing any. */
    [P in keyof T]?: T[P] extends AnyObject ? DeepPartialAny<T[P]> : any
}

interface Original {
    a: {
        a: string
        b: { a: string }
        c: { a: string }
    }
    b: string
    c: { a: string }
}

interface Overrides {
    a: {
        a: { a: number }  // <- overwrite string with object
        b: number         // <- overwrite object with number
        c: { b: number }  // <- add new child property
        d: number         // <- new primitive property
    }
    d: { a: number }    // <- new object property
}

//@ts-ignore // overriding an object with a flat value raises an error although the resulting type is calculated correctly
type ModifiedType = ModifyDeep<Original, Overrides>
//@ts-ignore
interface ModifiedInterface extends ModifyDeep<Original, Overrides> { }

// Try modifying the properties here to prove that the type is working
const t: ModifiedType = {
    a: {
        a: { a: 0 },
        b: 0,
        c: { a: '', b: 0 },
        d: 0,
    },
    b: '',
    c: { a: '' },
    d: { a: 0 },
}

/*
type DeepPartialAny is there just for type hints, but it's not perfect. 
Technically, the logic of the ModifyDeep type allows to replace leaf nodes {a: string} with objects {a: {b: ... }} and vice versa, 
but DeepPartialAny will complain when overriding an object with a flat primitive with an error such as this
*/