//public-static-const
//a get only accessor to the Library class:
export class Library {
    public static get BOOK_SHELF_NONE():string { return "None"; }
    public static get BOOK_SHELF_FULL():string { return "Full"; }   
}

var x = Library.BOOK_SHELF_NONE;
console.log(x);
Library.BOOK_SHELF_NONE = "Not Full";
x = Library.BOOK_SHELF_NONE;
console.log(x);
//If you run it, you'll see how the attempt to set the BOOK_SHELF_NONE property to a new value doesn't work.
//use readonly:
export class Library2 {
    public static readonly BOOK_SHELF_NONE = "None";
    public static readonly BOOK_SHELF_FULL = "Full";
}
/*
However, the compiler prevents changes rather than the run time 
(unlike in the first example, where the change would not be allowed at all as demonstrated).
cannot use these dynamic values as type constraint, for instance: 
*/
type MyType: Library.BOOK_SHELF_NONE | Library.BOOK_SHELF_FULL;



/*
export namespace Library3 {
    export const BOOK_SHELF_NONE: string = 'NONE';
}
import {Library3} from './Library';
console.log(Library.BOOK_SHELF_NONE);
*/