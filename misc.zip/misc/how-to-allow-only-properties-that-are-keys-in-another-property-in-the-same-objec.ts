/*
allow only properties that are keys in another property in the same object
https://stackoverflow.com/questions/63131415/how-to-allow-only-properties-that-are-keys-in-another-property-in-the-same-objec

a JSON object:

interface myCustomJson {
    id: string;
    properties: { [key: string]: 'one' | 'many' };
};
I want the properties object to describe what other properties exist on the object, 
where each of these properties is either an instance of myCustomJson itself or an array thereof (depending on the value in properties).

interface myCustomJson {
    id: string;
    properties: { [key: string]: 'one' | 'many' };
    [key: keyof myCustomJson['properties']]: myCustomJson | myCustomJson[];
};
gave the error "An index signature parameter type cannot be a union type. Consider using a mapped object type instead." 


an object like this:

const x: myCustomJson = {
    id: '1',
    properties: {
        header: 'one',
        children: 'many',
    },
    header: {
        id: '2',
        properties: {},
    },
    children: [],
};

any additional properties must be keys in the properties object
*/



// filter some keys from an object, based on their type.
type FilteredKeysSchema<T, U> = {
  [P in keyof T]: T[P] extends U ? P : never;
}[keyof T];

/**
 * Common Json "node" type.
 */
type JsonNode<Prop> = Prop & {
  id: string;
  properties: {
    [key in FilteredKeysSchema<
      Prop,
      JsonNode<unknown> | JsonNode<unknown>[]
    >]: Prop[key] extends Array<JsonNode<unknown>>
      ? "many"
      : Prop[key] extends JsonNode<unknown>
      ? "one"
      : never;
  };
};

interface Root {
  header: JsonNode<Header>;
  children: JsonNode<{}>[];
}

interface Header {
  title: string;
  description: string;
  buttons: JsonNode<Button>[];
}

interface Button {
  text: string;
}

/**
 * instantiation
 * try changing "one" to "many" & vice-versa
 * try changing types inside object themselves
 */
const x: JsonNode<Root> = {
  id: "1",
  properties: {
    header: "one",
    children: "many",
  },
  header: {
    id: "2",
    properties: {
      buttons: "many",
    },
    description: "",
    title: "",
    buttons: [
      {
        id: "10",
        properties: {},
        text: "Home",
      },
    ],
  },
  children: [],
};