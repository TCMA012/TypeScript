/*
Infer a record type from an Array type generic parameter
https://stackoverflow.com/questions/74099144/infer-a-record-type-from-an-array-type-generic-parameter
*/
enum ColumnType {
  text = "text",
  numeric = "numeric",
}

/*
The first step would be to capture more information about the columns. 
We can do this by making the whole array a type parameter. 
To make sure we capture literal types, we will 
add some type parameters for the names and column types of props to help TS 
infer literal types for those fields instead on inferring their wider types.

function consume<T extends Array<{ name: K; columnType: CT }>, K extends PropertyKey, CT extends ColumnType>(arg: Props<T>): void {}
We would also like to capture a tuple type instead of an array type to more easily process each element of the array. 
To do this, we can add a [] | to the type constraint:

function consume<T extends [] | Array<{ name: K; columnType: CT }>, K extends PropertyKey, CT extends ColumnType>(arg: Props<T>): void {}
In order to map the elements of the array to fields in an object, will need to use a mapped type.

use the 
as clause in mapped types to transform each element of the tuple to a field. We will need to 
filter only the indices of the tuple (we don't need the Array members). To do this we can 
intersect with `${number}` 
(tuple indices are actually represented as strings in the type system "0", "1" ... )
*/
type Row<T extends Array<{ name: PropertyKey; columnType: ColumnType }>> =  {} & {
  [K in keyof T & `${number}` as T[K]['name']]: T[K]['columnType'] extends ColumnType.numeric
      ? { content: number }
      : { content: string };
}

type Props<T extends Array<{ name: PropertyKey; columnType: ColumnType }>> = {
  columns: T;
  rows: Array<Row<T>>;
}

function consume<T extends [] | Array<{ name: K; columnType: CT }>, K extends PropertyKey, CT extends ColumnType>(arg: Props<T>): void {}



// missing fields, should not typecheck
consume({
  columns: [
    { name: "a", columnType: ColumnType.numeric },
    { name: "b", columnType: ColumnType.text },
  ],
  rows: [{}], 
});

// type mismatch, should not typecheck
consume({
  columns: [
    { name: "a", columnType: ColumnType.numeric },
    { name: "b", columnType: ColumnType.text },
  ],
  rows: [{ a: { content: "asdf" }, b: { content: 42 } }], 
});

// should typecheck
consume({
  columns: [
    { name: "a", columnType: ColumnType.numeric },
    { name: "b", columnType: ColumnType.text },
  ],
  rows: [{ a: { content: 42 }, b: { content: "asdf" } }],
});

/*
//? works with explicit type argument
consume<{ a: ColumnType.numeric; b: ColumnType.text }>({
  columns: [
    { name: "a", columnType: ColumnType.numeric },
    { name: "b", columnType: ColumnType.text },
  ],
  rows: [{ a: { content: 42 }, b: { content: "asdf" } }],
});
*/