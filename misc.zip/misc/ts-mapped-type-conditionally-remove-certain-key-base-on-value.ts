/*
Mapped Type: Conditionally remove certain key base on value
https://stackoverflow.com/questions/64746230/ts-mapped-type-conditionally-remove-certain-key-base-on-value
produce a mapped type that omit certain key base on the mapped key's value.

the TS team also think { key: never } should exclude the key, however due to some technical difficulty they cannot implement it.

Workaround is to create a utility type that filters desired keys, and apply it as an 
intermediate step.
*/
// Utilities:
type FilteredKeys<T> = { [P in keyof T]: T[P] extends never ? never : P }[keyof T];
type ExcludeNeverFields<O> = {
  [K in FilteredKeys<O>]: O[K]
}

// Use case:
type DataParams = {
  trade: never;
  trade_bar: {
    interval: number;
    intervalUnit: "ms" | "s" | "m" | "ticks" | "vol";
  };
};

type DataTypes = keyof DataParams;

type Options = {
  [DataType in DataTypes]: ExcludeNeverFields<{
    type: DataType;
    params: DataParams[DataType];
  }>
}[DataTypes];