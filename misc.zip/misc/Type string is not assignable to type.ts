/*
prevent literal types (eg. 'orange' or 'red') being 'widened' to type string with a so-called const assertion.
Type 'string' is not assignable to type
*/
export type Fruit = "Orange" | "Apple" | "Banana"
let fruit:Fruit = "Banana" as const;
let fruit2 = "Banana" as const;
let fruit3 = <const> 'Orange';

//do it on a whole object:
let animals = [ { species: 'dog' }, { species: 'cat' } ] as const;
type firstAnimal = (typeof animals)[0]['species'];  // string literal 'dog'
/*
can also use <const> false or <const> true to represent a boolean that must be true or false. 
This can be useful in discriminated unions sometimes.
*/
let myString:string = "Banana";
let myFruit0:Fruit = myString;
let myFruit:Fruit = "Banana";