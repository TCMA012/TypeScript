/*
An index signature parameter type cannot be a union type. Consider using a mapped object type instead
*/
enum MyOption {
  ONE = 'one',
  TWO = 'two',
  THREE = 'three'
}

interface MyOptionRequirement {
  someBool: boolean;
  someString: string;
}

/*
interface MyOptionRequirements {
  [key: MyOption]: MyOptionRequirement; //error
}
*/

type OptionRequirements = {
    [key in MyOption]: MyOptionRequirement; // Note the "in" operator.
}

type OptionRequirements2 = Record<MyOption, MyOptionRequirement>