//https://stackoverflow.com/questions/14638990/are-strongly-typed-functions-as-parameters-possible-in-typescript
class Foo {
    save(callback: (n: number) => any) : void {
        callback(42);
    }
}
var foo = new Foo();

var strCallback = (result: string) : void => {
    alert(result);
}
var numCallback = (result: number) : void => {
    alert(result.toString());
}

foo.save(strCallback); // not OK
foo.save(numCallback); // OK



//a type alias:
type NumberCallback = (n: number) => any;
type BooleanCallback = (n: boolean) => string;
type StringCallback = (n: string) => bigint;
type BigintCallback = (n: bigint) => bigint;

class Foo2 {
    // Equivalent
    save(callback: NumberCallback) : void {
        callback(42);
    }

    write(callback: BooleanCallback) : string {
        return callback(true);
    }

    put(callback: StringCallback) : bigint {
        return callback('a');
    }
    
    update(callback: BigintCallback) : bigint {
        return callback(1n);
    }
}