/*
type level equal operator
https://github.com/Microsoft/TypeScript/issues/27024
https://stackoverflow.com/questions/53807517/how-to-test-if-two-types-are-exactly-the-same
https://stackoverflow.com/questions/75699574/generic-arrow-functions-in-conditional-types
https://github.com/type-challenges/type-challenges/issues/5221#issue-1082962800

Here's a solution that makes creative use of the assignability rule for conditional types, 
which requires that the types after extends be "identical" as that is defined by the checker:
*/
export type Equals<X, Y> =
    (<T>() => T extends X ? 1 : 2) extends
    (<T>() => T extends Y ? 1 : 2) ? true : false;
/*
This passes all the tests from the initial description that I was able to run except H, 
which fails because the definition of "identical" 
doesn't allow an intersection type to be identical to an object type with the same properties. 
(I wasn't able to run test E because I don't have the definition of Head.)
*/
/*
@MattMcCutchen has come up with a solution, described in a comment on that issue involving generic conditional types which does a decent job of detecting when two types are exactly equal, as opposed to just mutually assignable. In a perfectly sound type system, "mutually assignable" and "equal" would probably be the same thing, but TypeScript isn't perfectly sound. In particular, the any type is both assignable to and assignable from any other type, meaning that string extends any ? true : false and any extends string ? true: false both evaluate to true, despite the fact that string and any are not the same type.

Here's an IfEquals<T, U, Y, N> type which evaluates to Y if T and U are equal, and N otherwise.
*/
type IfEquals<T, U, Y=unknown, N=never> =
  (<G>() => G extends T ? 1 : 2) extends
  (<G>() => G extends U ? 1 : 2) ? Y : N;

type EQ = IfEquals<any[], [number][], "same", "different">; // "different"
/*
those are recognized as different types. 
There are probably some other edge cases where two types that you think are the same are seen as different, and vice versa:
*/
type EQ1 = IfEquals<
  { a: string } & { b: number },
  { a: string, b: number },
  "same", "different">; // "different"!

type EQ2 = IfEquals<
  { (): string, (x: string): number },
  { (x: string): number, (): string },
  "same", "different">; // "different", as expected, but:

type EQ3 = IfEquals<
  { (): string } & { (x: string): number },
  { (x: string): number } & { (): string },
  "same", "different">; // "same"!! but they are not the same, 
// intersections of functions are order-dependent
//Anyway, given this type we can make a function that generates an error unless the two types are equal in this way:

/** Trigger a compiler error when a value is _not_ an exact type. */
declare const exactType: <T, U>(
  draft: T & IfEquals<T, U>,
  expected: U & IfEquals<T, U>
) => IfEquals<T, U>

declare let a: any[]
declare let b: [number][]

// $ExpectError
exactType(a, b) // error
/*
Each argument has a type T or U (for type inference of the generic parameter) intersected with IfEquals<T, U> so that there will be an error unless T and U are equal. This gives the behavior you want, I think.

Note that the arguments of this function are not optional. I don't really know why you wanted them to be optional, but (at least with --strictNullChecks turned on) it weakens the check to do so:
*/
declare let c: string | undefined
declare let d: string
exactType(c, d) // no error if optional parameters!
//It's up to you if that matters.



/*
It's actually not particularly illuminating to understand what T is doing in
 <T>() => T extends X ? 1 : 2. 
 Let's forget about that for now and come back to it later.

You're looking at a particular implementation of the so-called type-level equality operator, as discussed in 
How to test if two types are exactly the same. 
There are types in TypeScript which are mutually assignable 
(that is, you can assign a value of type X to a variable of type Y and vice versa) 
but which are represented differently by the compiler. 
For example, the intersection {a: 0} & {b: 1} is mutually assignable to the single object type {a: 0; b: 1}, 
but they are not considered "identical" according to the compiler. 
The goal of MyEqual<X, Y> is to somehow get the compiler to tell you whether it considers X and Y to be identical and 
not just mutually assignable.

Most naive implementations would give you the latter:
type MyEqual<X, Y> = [X] extends [Y] ? [Y] extends [X] ? true : false : false

One approach you could take is to find a "black box" type function which is so complicated that 
the compiler has no idea how to analyze what it does. 
We don't really care what it does either, just that the compiler can't do any analysis on it. 
So we're looking for a type function like
type BlackBox<Z> = ⋯Z⋯ // something goes here
that's so complicated that the compiler only thinks BlackBox<X> extends BlackBox<Y> if X and Y are completely identical. 
If they're not identical then the compiler just gives up and says that BlackBox<X> and BlackBox<Y> are different.

Then you could almost write MyEqual like

type MyEqual<X, Y> = BlackBox<X> extends BlackBox<Y> ? true : false;
...except that the compiler will take a shortcut since both are referring to the same BlackBox definition. 
So the approach will have to be to either inline BlackBox into MyEqual like

type MyEqual<X, Y> = ⋯X⋯ extends ⋯Y⋯ ? true : false;
// where ⋯X⋯ is what you get if you copy `BlackBox<X>` 
// definition in manually
or define two syntactically identical BlackBox type functions. That is, we can write

type BlackBox1<Z> = ⋯Z⋯
type BlackBox2<Z> = ⋯Z⋯ // <-- identical to the above except for the name
type MyEqual<X, Y> = BlackBox1<X> extends BlackBox2<Y> ? true : false;
So now the goal is to look for an appropriate BlackBox<Z> definition. It turns out that the following one works:
*/
type BlackBox<Z> = <T>() => T extends Z ? 1 : 2
//and therefore you could write
type BlackBoxA<Z> = <T>() => T extends Z ? 1 : 2
type BlackBoxB<Z> = <T>() => T extends z ? 1 : 2
type MyEqual<X, Y> = BlackBoxA<X> extends BlackBoxB<Y> ? true : false;
//or the equivalent

type MyEqual<X, Y> = (<T>() => T extends X ? 1 : 2) extends 
  (<T>() => T extends Y ? 1 : 2) ? true : false;
/*
Again, we really don't care what BlackBox<Z> does to Z or what type it represents. 
It's not important for our purposes. We really only need it to be a "black box". 
Still, you seem to want to know, so let's look at it. 
But don't be surprised if it makes no sense or seems to serve no purpose. 
It's because to some extent it does make no sense and doesn't serve a purpose.

 given:
type BlackBox<Z> = <T>() => T extends Z ? 1 : 2
what do we get if we plug in something for Z. Say, string? then we get
*/
type BlackBoxString = <T>() => T extends string ? 1 : 2
/*
That's a generic function type which takes one type argument T and no function arguments, 
and returns a value of the conditional type T extends string ? 1 : 2. 
As written, T isn't currently doing anything, because 
in generic functions, type parameters stay unresolved until such time as you call the function. 
So T won't be anything until we have a function of this type and call it.

Let's see what should happen if we had a function of this type and called it:
*/
declare const bbs: BlackBoxString;

const t = bbs(); // T cannot be inferred, becomes unknown
// const t: 2;
const u = bbs<string>();
// const u: 1;
const v = bbs<number>();
// const v: 2;
const w = bbs<"abc">();
// const w: 1;
const x = bbs<string | number>();
// const x: 1 | 2;
/*
So when you call bbs() and don't manually specify its type argument, type inference completely fails 
(there's nowhere for T to be inferred), and it falls back to unknown. 
So bbs() produces a value of type unknown extends string ? 1 : 2 which is 2 because unknown does not extend string. 
If you manually specify the type arguments you get 
either 1 or 2 or 1 | 2 out of the function depending on whether or not the type argument is string-ish.

This is a useless function type. Nobody would ever want a function of this type. It doesn't do anything good for anyone. 
And it's lucky that nobody wants a function like this, since it's completely 
impossible to actually implement a function of this type. 
At runtime there is no T, and so bbs would have to somehow know whether to output 1 or 2 based on information it doesn't have.

So BlackBox<Z> represents a completely useless and almost always unimplementable generic function type. 
But again, we don't really care what it does.
*/