/*
add Date if the firestore.Timestamp is already present in the property type.

I think the cleanest solution would be to use a distributive conditional type to add the extra constituent of the union. 
With a distributive conditional type we can consider each constituent of the union and 
add Date if it is Timestamp or 
leave it unchanged if it is not. 

For distribution to happen, you need the condition to be over a naked type parameter. 
T extends Timestamp is distributive, 
T[K] extends Timestamp is not. 
T[K] extends infer U ? U extends TimeStamp? ... would also be distributive over U but is hard to read so I generally avoid it 
*/
/*
type firestore = {
    Timestamp : number;
}

export type AddTimeStamp<T> = T extends firestore.Timestamp?
           firestore.Timestamp | Date:
           T;
*/
type Timestamp = number

export type AddTimeStamp<T> = T extends Timestamp?
           Timestamp | Date:
           T;

export type MapToInput<T> = {
    [K in keyof T]: AddTimeStamp<T[K]>;
};

interface Boop {
    a: boolean;
}
  
type x = MapToInput<Boop>;
type y = MapToInput<Timestamp>;