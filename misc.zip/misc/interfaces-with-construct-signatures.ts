/*
https://stackoverflow.com/questions/13407036/how-does-interfaces-with-construct-signatures-work

Construct signatures in interfaces are not implementable in classes; 
they're only for defining existing JS APIs that define a 'new'-able function. 
interfaces new signatures:

More formally, a class implementing an interface is a contract on what an instance of the class has. 
Since an instance of a class won't contain a construct signature, it cannot satisfy the interface.
*/
interface ComesFromString {
    name: string;
}

interface StringConstructable {
    new(n: string): ComesFromString;
}

class MadeFromString implements ComesFromString {
    constructor (public name: string) {
        console.log('ctor invoked');
    }
}

function makeObj(n: StringConstructable) {
    return new n('hello!');
}

console.log(makeObj(MadeFromString).name);

//This creates an actual constraint for what you can invoke makeObj with:
class Other implements ComesFromString {
    constructor (public name: string, count: number) {
    }
}

makeObj(Other); // Error! Other's constructor doesn't match StringConstructable



/*
declaring an interface and afterwards a variable with a name matching exactly the interface-name. 
This is also the way to type static functions.
Example from lib.d.ts:


interface Object {
    toString(): string;
    toLocaleString(): string;
    // ... rest ...
}
declare var Object: {
    new (value?: any): Object;
    (): any;
    (value: any): any;
    // ... rest ...
}
*/
interface ObjectMy {
    toString(): string;
    toLocaleString(): string;
    // ... rest ...
}
declare var ObjectMy: {
    new (value?: any): ObjectMy;
    (): any;
    (value: any): any;
    // ... rest ...
}
/*
creating instances of the same type. 
public reparse(statement: string): this 
{ 
    type t = new (statement: string) => this; 
    let t = this.constructor as t; return new t(statement); 
} 
   
Identifiers are associated with three things: 
values, types, and namespaces. 
Things like classes that associate both with a name can get out of sync
*/


/*
an array of interfaces 
const objs: ComesFromString[] = [MadeFromString, AnotherOne, MoreString];
how would I go about creating instances from those? 
say in a loop: 
_.each(objs, (x) => makeObj(x)?
This will throw an error since x is of type ComesFromString and doesn't have a constructor. 

ComesFromString is not the correct type annotation for objs as it implies each objs element is an instance of that type, 
not a constructor for it. You want 
objs: StringConstructable[]
*/



/*
an interface with a construct signature is not meant to be implemented by any class
(at first glance this might look weird for guys with C#/Java background like me but give it a chance).
It is slightly different.
For a moment, think of it as an interface with a call signature(like a @FunctionalInterface in the Java world). 
Its purpose is to describe a function type...kind of. 
The described signature is supposed to be satisfied by a function object...but not just any high-level function or a method. 
It should be a function that knows how to construct an object, a function that gets called when the new keyword is used.

So an interface with a construct signature defines the signature of a constructor! 
The constructor of your class that should comply with the signature defined in the interface
(think of it as the constructor implements the interface). It is like a factory!

Here is a snippet of code that tries to demonstrate the most common usage:
*/
interface ClassicInterface { // old school interface like in C#/Java
    method1();
    //...
    methodN();
}

interface Factory { //knows how to construct an object
    // NOTE: pay attention to the return type
    new (myNumberParam: number, myStringParam: string): ClassicInterface
}

class MyImplementation implements ClassicInterface {
    // The constructor looks like the signature described in Factory
    constructor(num: number, s: string) { } // returns an instance of ClassicInterface
    method1() {}
    //...
    methodN() {}
//?    log(param: any) {console.log('num', this.num, 's', s)}
}

class MyOtherImplementation implements ClassicInterface {
    // The constructor looks like the signature described in Factory
    constructor(n: number, s: string) { } // returns an instance of ClassicInterface
    method1() {}
    //...
    methodN() {}
}

// And here is the polymorphism of construction
function instantiateClassicInterface(ctor: Factory, myNumberParam: number, myStringParam: string): ClassicInterface {
    return new ctor(myNumberParam, myStringParam);
}

let iWantTheFirstImpl = instantiateClassicInterface(MyImplementation, 3.14, "smile");
let iWantTheSecondImpl = instantiateClassicInterface(MyOtherImplementation, 42, "vafli");



/*
When a class implements an interface, only the instance side of the class is checked. 
Since the constructor sits in the static side, it is not included in this check.
Instead, you would need to work with the static side of the class directly. 
We define two interfaces, ClockConstructor for the constructor and ClockInterface for the instance methods. 
Then we define a constructor function createClock that creates instances of the type that is passed to it:
*/
interface ClockConstructor {
  new (hour: number, minute: number): ClockInterface;
}

interface ClockInterface {
  tick(): void;
}

function createClock(
  ctor: ClockConstructor,
  hour: number,
  minute: number
): ClockInterface {
  return new ctor(hour, minute);
}

class DigitalClock implements ClockInterface {
  constructor(h: number, m: number) {}
  tick() {
    console.log("beep beep");    
    //console.log("beep beep",this.h,);
  }
}

class AnalogClock implements ClockInterface {
  constructor(h: number, m: number) {}
  tick() {
    console.log("tick tock");
  }
}

let digital = createClock(DigitalClock, 12, 17);
let analog = createClock(AnalogClock, 7, 32);
digital.tick
//digital.h
//digital.hour
analog.tick



/*
//a generic new-able function with the same technique:
interface MyArrayConstructor {
    <T>(...elements: Array<T>): MyArrayInstance<T>
    new <T> (...elements: Array<T>): MyArrayInstance<T>
}

// “Typecast” not the function itself, but another symbol,
// so that the body of myArray will also benefit from type-checking:
export const MyArray = myArray as MyArrayConstructor

interface MyArrayInstance<T> {
    push(...args: Array<T>): number
    slice(from?: number, to?:number): Array<T>
}

function myArray<T>(...elements: Array<T>): MyArrayInstance<T> {
  return {
    push(...args) { }
    slice(from?: number, to?: number) { }
  }
}
*/