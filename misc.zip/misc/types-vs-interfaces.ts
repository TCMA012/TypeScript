//https://blog.logrocket.com/types-vs-interfaces-typescript/
type AddFn = (num1: number, num2: number) => number;

interface IAdd {
    (num1: number, num2: number): number;
}



type Car = 'ICE' | 'EV';
type ChargeEV = (kws: number) => void;
type FillPetrol = (type: string, liters: number) => void;
type RefillHandler<A extends Car> = A extends 'ICE' ? FillPetrol : A extends 'EV' ? ChargeEV : never;
const chargeTesla: RefillHandler<'EV'> = (power) => {
    // Implementation for charging electric cars (EV)
};
const refillToyota: RefillHandler<'ICE'> = (fuelType, amount) => {
    // Implementation for refilling internal combustion engine cars (ICE)
};



/*
the intersection operator merges the method signature of the two getPermission declarations, and 
a typeof operator is used to narrow down the union type parameter so that we can get the return value in a type-safe way:
*/
type PersonRock = {
    getPermission: (id: string) => string;
};

type StaffRock = PersonRock & {
    getPermission: (id: string[]) => string[];
};

const AdminStaff: StaffRock = {
    getPermission: (id: string | string[]) => {
        return (typeof id === 'string' ? 'admin' : ['admin']) as string[] & string;
    }
}



type Client = {
    name: string;
    address: string;
}
type Getters<T> = {
    [K in keyof T as `get${Capitalize<string & K>}`]:  () => T[K];
};
type clientType = Getters<Client>;
// type clientType = {
//     getName: () => string;
//     getAddress: () => string;
// }