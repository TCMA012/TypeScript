//check if a string is Numeric
Number('1234') // 1234
Number('9BX9') // NaN

//use the unary plus operator:
+'1234' // 1234
+'9BX9' // NaN

//Be careful when checking against NaN (the operator === and !== don't work as expected with NaN). Use:
let maybeNumber
isNaN(+maybeNumber) // returns true if NaN, otherwise false



function isNumber(value?: string | number): boolean
{
   return ((value != null) &&
           (value !== '') &&
           !isNaN(Number(value.toString())));
}