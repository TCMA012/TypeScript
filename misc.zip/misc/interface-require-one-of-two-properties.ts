/*
https://stackoverflow.com/questions/40510611/typescript-interface-require-one-of-two-properties-to-exist
https://learn.microsoft.com/en-us/javascript/api/@azure/keyvault-certificates/requireatleastone?view=azure-node-latest
*/
type RequireAtLeastOne<T, Keys extends keyof T = keyof T> =
    Pick<T, Exclude<keyof T, Keys>> 
    & {
        [K in Keys]-?: Required<Pick<T, K>> & Partial<Pick<T, Exclude<Keys, K>>>
    }[Keys]
//a partial but not absolute way to require that one and only one is provided is:
type RequireOnlyOne<T, Keys extends keyof T = keyof T> =
    Pick<T, Exclude<keyof T, Keys>>
    & {
        [K in Keys]-?:
            Required<Pick<T, K>>
            & Partial<Record<Exclude<Keys, K>, undefined>>
    }[Keys]
/*    
Here is a TypeScript playground link showing both in action.

The caveat with RequireOnlyOne is that TypeScript doesn't always know at compile time every property that will exist at runtime. 
So obviously RequireOnlyOne can't do anything to prevent extra properties it doesn't know about. 
I provided an example of how RequireOnlyOne can miss things at the end of the playground link.

A quick overview of how it works using the following example:
*/
interface MenuItem {
  title: string;
  component?: number;
  click?: number;
  icon: string;
}

type ClickOrComponent = RequireAtLeastOne<MenuItem, 'click' | 'component'>
/*
Pick<T, Exclude<keyof T, Keys>> from RequireAtLeastOne becomes { title: string, icon: string}, 
which are the unchanged properties of the keys not included in 'click' | 'component'

{ [K in Keys]-?: Required<Pick<T, K>> & Partial<Pick<T, Exclude<Keys, K>>> }[Keys] from RequireAtLeastOne becomes

{ 
    component: Required<{ component?: number }> & { click?: number }, 
    click: Required<{ click?: number }> & { component?: number } 
}[Keys]
Which becomes

{
    component: { component: number, click?: number },
    click: { click: number, component?: number }
}['component' | 'click']
Which finally becomes

{component: number, click?: number} | {click: number, component?: number}
//The intersection of steps 1 and 2 above
{ title: string, icon: string} 
& 
({component: number, click?: number} | {click: number, component?: number})
//simplifies to

{ title: string, icon: string, component: number, click?: number} 
| { title: string, icon: string, click: number, component?: number}




1. The Keys generic param is optional. 
If is provided, only those keys will produce a new object type in the final union, 
if is not provided, all keys of T will produce object types in the final union. 
2. The first Exclude excludes all keys that are not in Keys param, and
 merges them in all the object types in the final union, without any changes to their ? modifier. 
3. The -? removes the optional modifier on all the target keys. 
4. Required<...> & Partial<...> finalizes the trick! 
The Required part makes the current key required, the Partial part makes all remaining keys optional. 
*/
/*
Omit helper (a shortcut for Pick + Exclude): 
type RequireAtLeastOne<T, R extends keyof T = keyof T> = 
Omit<T, R> & {   [ P in R ] : Required<Pick<T, P>> & Partial<Omit<T, P>> }[R];
The base frame is the same, so only warrants a comment
(quick note: in [K in keys]-?:, the -? modifier can be safely omitted: optionality is preserved in both versions) 
*/
export type RequireOnlyOne2<T, Keys extends keyof T = keyof T> = Omit<T, Keys> &
    { [K in keyof Required<T>]: Required<Pick<T, K>>
        & Partial<Record<Exclude<Keys, K>, undefined>>; }[Keys];  
//We can change the -?: operator to set the Type from the second generic type as required 




type MenuItemOr = {
    title: string;
    icon: string;
} & ({ component: object } | { click: boolean }) 
// brackets are important here: "&" has precedence over "|"

let testOr: MenuItemOr;
testOr = { title: "t", icon: "i" } // error, none are set
testOr = { title: "t", icon: "i", component: {} } // ✔
testOr = { title: "t", icon: "i", click: true } // ✔
testOr = { title: "t", icon: "i", click: true, component: {} } // ✔
/*
A union type (|) corresponds to inclusive OR. It is intersected with the non-conditional properties.

Use the in operator to narrow the value back to one of the constituents:
*/
if ("click" in testOr) testOr.click // works 
//both properties can't be set (Exclusive OR / XOR)
type MenuItemXor = {
    title: string;
    icon: string;
} & (
        | { component: object; click?: never }
        | { component?: never; click: boolean }
    )

let testXor: MenuItemXor;
testXor = { title: "t", icon: "i" } // error, none are set
testXor = { title: "t", icon: "i", component: {} } // ✔
testXor = { title: "t", icon: "i", click: true } // ✔
testXor = { title: "t", icon: "i", click: true, component: {} } //error,both set
/*
either component or click can be set, 
the other should 
never (Technically, prop?: never gets resolved to prop?: undefined, though former is often used for illustration.)
be added at the same time. 
TS can make a discriminated union type out of MenuItemXor, which corresponds to XOR.
This XOR condition for MenuItemXor is not possible with accepted answer.
*/



export type MenuItem3 = {
    title: string;
    component: any;
    icon: string;
} | {
    title: string;
    click: any;
    icon: string;
};

const item: MenuItem3[] = [
    { title: "", icon: "", component: {} },
    { title: "", icon: "", click: "" },
    // Shouldn't this error out because it's passing a property that is not defined
    { title: "", icon: "", click: "", component: {} },
    // Does error out :)
    { title: "", icon: "" }
];



//splitting the interfaces:
export interface BaseMenuItem {
  title: string;
  icon: string;
}

export interface ComponentMenuItem extends BaseMenuItem {
  component: any;
}

export interface ClickMenuItem extends BaseMenuItem {
    click: any;
}

export type MenuItem2 = ComponentMenuItem | ClickMenuItem;



//github.com/sindresorhus/type-fest