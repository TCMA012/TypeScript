/*
https://stackoverflow.com/questions/52677576/typescript-discriminated-union-allows-invalid-state/

https://www.typescriptlang.org/docs/handbook/release-notes/typescript-3-5.html#improved-excess-property-checks-in-union-types
the type-checker at least verifies that all the provided properties belong to some union member and have the appropriate type.
partial overlap is still permitted as long as the property types are valid
*/
{
type LoadingState = { isLoading: true; }
type SuccessState = { isLoading: false; isSuccess: true; }
type ErrorState =   { isLoading: false; isSuccess: false; errorMessage: string; }

type State = LoadingState | SuccessState | ErrorState;
/*
this should limit the allowed combinations of values according to the type definitions. 
However, the type system is happy to accept the following combination:
*/
const testState: State = {
    isLoading: true,
    isSuccess: true,
    errorMessage: "Error!"
}
}
/*
This is an issue with the way excess property checks work on unions. 
If an object literal is assigned to a variable of union type, 
a property will not be marked as excess if it is present on any of the union members. 
If we don't consider excess properties to be an error 
(and except for object literals they are not considered an error), 
the object literal you specified could be an instance of LoadingState 
(an instance with isLoading set to true as mandated and a couple of excess properties).

To get around this undesired behavior we can 
add properties to LoadingState to make your object literal incompatible with LoadingState
*/
{
type LoadingState = { isLoading: true; isSuccess?: undefined }
type SuccessState = { isLoading: false; isSuccess: true; }
type ErrorState =   { isLoading: false; isSuccess: false; errorMessage: string; }

type State = LoadingState | SuccessState | ErrorState;

const testState0: State = { // error
    isLoading: true,
    isSuccess: true,
    errorMessage: "Error!"
}
}

//We could even create a type that would ensure such member will be added

/*
https://github.com/andnp/SimplyTyped#strictunion
*/
type LoadingState = { isLoading: true; }
type SuccessState = { isLoading: false; isSuccess: true; }
type ErrorState =   { isLoading: false; isSuccess: false; errorMessage: string; }

type UnionKeys<T> = T extends T ? keyof T : never;
type StrictUnionHelper<T, TAll> = T extends any ? T & Partial<Record<Exclude<UnionKeys<TAll>, keyof T>, undefined>> : never;
type StrictUnion<T> = StrictUnionHelper<T, T>

type State = StrictUnion< LoadingState | SuccessState | ErrorState>

const testState: State = { // error
    isLoading: true,
    isSuccess: true,
    errorMessage: "Error!"
}