/*
https://stackoverflow.com/questions/37688318/typescript-interface-possible-to-make-one-or-the-other-properties-required
If you're truly after "one property or the other" and not both you can use never in the extending type:
*/
type Props =
  | { factor: string; ratings?: never }
  | { ratings: number[]; factor?: never }



{
type Only<T, U> = {
    [P in keyof T]: T[P];
} & {
        [P in keyof U]?: never;
    };

type Either<T, U> = Only<T, U> | Only<U, T>;


interface MessageBasics {
    timestamp?: number;
    /* more general properties here */
}
interface MessageWithText extends MessageBasics {
    text: string;
}
interface MessageWithAttachment extends MessageBasics {
    attachment: string;
}
type Message = Either<MessageWithText, MessageWithAttachment>;

let foo: Message = {attachment: 'a'}
let bar: Message = {text: 'b'}
let baz: Message = {attachment: 'a', text: 'b'}
}



interface MessageBasics {
  timestamp?: number;
  /* more general properties here */
}
interface MessageWithText extends MessageBasics {
  text: string;
  attachment?: never;
}
interface MessageWithAttachment extends MessageBasics {
  text?: never;
  attachment: string;
}
type Message = MessageWithText | MessageWithAttachment;

// 👍 OK 
let foo: Message = {attachment: 'a'}

// 👍 OK
let bar: Message = {text: 'b'}

// ❌ ERROR: Type '{ attachment: string; text: string; }' is not assignable to type 'Message'.
let baz: Message = {attachment: 'a', text: 'b'}



//array type
interface BaseRule {
  optionalProp?: number
}

interface RuleA extends BaseRule {
  requiredPropA: string
}

interface RuleB extends BaseRule {
  requiredPropB: string
}

type SpecialRulesArray = Array<RuleA | RuleB>

// or
type SpecialRules = (RuleA | RuleB)[]

// or (in the strict linted project I'm in):
type SpecialRule = RuleA | RuleB
type SpecialRules2 = SpecialRule[]

//use the (variable as type) syntax.
const myRules: SpecialRules = [
  {
    optionalProp: 123,
    requiredPropA: 'This object is of type RuleA'
  },
  {
    requiredPropB: 'This object is of type RuleB'
  }
]

myRules.map((rule) => {
  if ((rule as RuleA).requiredPropA) {
    // do stuff
  } else {
    // do other stuff
  }
})

/*
there is a type-safe, intellisense-friendly way to write your .map() code. 
Use type-guard with the
in 
operator. TypeScript will do proper type inference, etc. 
So your condition would be 
if ('requiredPropA' in rule) { 
    // inside here, TS knows rule is of type <RuleA>  
}
*/



