/*
return-type-for-setTimeout
Simplest solution is to allow type inference to work and not specify any type at all. 
If you need to specify a type, seeing as the type is not consistent between the browser and node declarations, you could use 
ReturnType 
to specify that the type of the variable is whatever the return type of setTimeout is:
*/
const timer: ReturnType<typeof setTimeout> = setTimeout(() => '', 1000);
/*
Alternately, 
window.setTimeout 
can also be used instead of just 
setTimeout. It returns proper return type.
*/