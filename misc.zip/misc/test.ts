//document.body.addEventListener("mousedo
//document.body.addEventListener('mousedown');

EventListenerOrEventListenerObject