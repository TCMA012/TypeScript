/*
unions vs enums
https://stackoverflow.com/questions/40275832/typescript-has-unions-so-are-enums-redundant
prefer union types to enums.
How to declare iterable union types
*/

const permissions = ['read', 'write', 'execute'] as const;
type Permission = typeof permissions[number]; // 'read' | 'write' | 'execute'

// you can iterate over permissions
for (const permission of permissions) {
  // do something
}
//When the actual values of the union type do not describe theirselves very well, you can name them as you do with enums.

// when you use enum
enum Permission2 {
  Read = 'r',
  Write = 'w',
  Execute = 'x'
}

// union type equivalent
const Permission3 = {
  Read: 'r',
  Write: 'w',
  Execute: 'x'
} as const;
type Permission4 = typeof Permission2[keyof typeof Permission2]; // 'r' | 'w' | 'x'

// of course it's quite easy to iterate over
for (const permission of Object.values(Permission3)) {
  console.log('permission', permission)
}
/*
Do not miss as const assertion which plays the crucial role in these patterns.

Why it is not good to use enums?
*/