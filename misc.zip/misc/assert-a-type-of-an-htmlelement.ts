//assert-a-type-of-an-htmlelement
var script = <HTMLScriptElement>document.getElementsByName("script")[0];

let id = "script";
(<HTMLScriptElement[]>document.getElementsByName(id))[0]; //error
(<HTMLScriptElement[]><unknown>document.getElementsByName(id))[0];