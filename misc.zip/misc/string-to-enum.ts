//https://stackoverflow.com/questions/17380845/how-do-i-convert-a-string-to-enum-in-typescript
enum Color{
    Red, Green
}

// To String
var green: string = Color[Color.Green];

// To Enum / number ???
var color : Color = Color[green];
console.log("color", color);




let typedColor: Color = Color.Green;
let typedColorString: keyof typeof Color = "Green";
console.log("typedColorString0", typedColorString);


// Error "Black is not assignable ..." (indexing using Color["Black"] will return undefined runtime)
typedColorString = "Black";

// Error "Type 'string' is not assignable ..." (indexing works runtime)
let letColorString = "Red";
typedColorString = letColorString;

// Works fine
typedColorString = "Red";
console.log("typedColorString", typedColorString);

// Works fine
const constColorString = "Red";
typedColorString = constColorString

{
// Works fine (thanks @SergeyT)
let letColorString = "Red";
typedColorString = letColorString as keyof typeof Color;

typedColor = Color[typedColorString];
}