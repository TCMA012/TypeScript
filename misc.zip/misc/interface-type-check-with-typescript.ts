/*
https://stackoverflow.com/questions/14425568/interface-type-check-with-typescript
find out at runtime if a variable of type any implements an interface.
custom type guard:
*/
interface A {
    member: string;
}

function instanceOfA(object: any): object is A {
    return 'member' in object;
}

var a: any = {member: "foobar"};

if (instanceOfA(a)) {
    console.log(a.member);
}

/*
If you need to check a lot of members to determine whether an object matches your type, you could instead add a discriminator. 
avoid duplicate discriminators.
*/
interface discriminatorD {
    discriminator: 'I-AM-discriminatorD';
    member: string;
}

function instanceOfdiscriminatorD(object: any): object is discriminatorD {
    return object.discriminator === 'I-AM-discriminatorD';
}

var a: any = {discriminator: 'I-AM-discriminatorD', member: "memb1"};

if (instanceOfdiscriminatorD(a)) {
    console.log(a.member);
}