/*
TypeScript error "The operand of a 'delete' operator must be optional"
https://stackoverflow.com/questions/63702057/what-is-the-logic-behind-the-typescript-error-the-operand-of-a-delete-operato

When using the delete operator in strictNullChecks, 
the operand must now be any, unknown, never, or be optional 
(in that it contains undefined in the type). Otherwise, use of the delete operator is an error.
*/
interface Thing {
    prop: string;
}

function f(x: Thing) {
    delete x.prop; // throws error = The operand of a 'delete' operator must be optional.
}
/*
interface Thing is a contract asking to have a (non-null, non-undefined) prop as a string.

If one removes the property, then the contract is not implemented anymore.

If you want it still valid when removed, just declare it as optional with a : 
prop?: string
*/