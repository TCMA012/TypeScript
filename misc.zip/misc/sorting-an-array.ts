/*
sorting-an-array
Numbers
use the compact comparison:
i.e. - rather than <.
*/
var numericArray: number[] = [2, 3, 4, 1, 5, 8, 11];
var sortedArray: number[] = numericArray.sort((n1, n2) => n1 - n2);

/*
Other Types
If you are comparing anything else, you'll need to convert the comparison into a number.
*/
var stringArray: string[] = ['AB', 'Z', 'A', 'AC'];
var sortedStringArray: string[] = stringArray.sort((n1,n2) => {
    if (n1 > n2) {
        return 1;
    }
    if (n1 < n2) {
        return -1;
    }
    return 0;
});

/*
Objects
sort based on a property, bear in mind the above information about being able to short-hand number types. 
The below example works irrespective of the type.
*/
var objectArray: { age: number; }[] = [{ age: 10}, { age: 1 }, {age: 5}];
var sortedObjectArray: { age: number; }[] = objectArray.sort((n1,n2) => {
    if (n1.age > n2.age) {
        return 1;
    }
    if (n1.age < n2.age) {
        return -1;
    }
    return 0;
});



type SortArrayType = <T>(arr: T[]) => T[];
const sortArray: SortArrayType = (arr) => {
  return arr.sort((a, b) => {
    const strA = JSON.stringify(a);
    const strB = JSON.stringify(b);
    if (strA < strB) {
      return -1;
    }
    if (strA > strB) {
      return 1;
    }
    return 0;
  });
};



let numericArray2: number[] = [2, 3, 4, 1, 5, 8, 11];

//let sortFn = (n1 , n2) => number { return n1 - n2; }
let sortFn = (n1 , n2) => { return n1 - n2; }

const sortedArray2: number[] = numericArray2.sort(sortFn);

/*
//Sort by some field:
let arr:{key:number}[] = [{key : 2}, {key : 3}, {key : 4}, {key : 1}, {key : 5}, {key : 8}, {key : 11}];

//let sortFn2 = (obj1 , obj2) => {key:number} { return obj1.key - obj2.key; }
let sortFn2 = (obj1 , obj2) => {key} { return obj1.key - obj2.key; }

const sortedArray2b:{key:number}[] = arr.sort(sortFn2);
*/
/*
if (sortBy === 'date') {
    return n1.date - n2.date
} else {
    if (n1.title > n2.title) {
       return 1;
    }
    if (n1.title < n2.title) {
        return -1;
    }
    return 0;
}
*/