/*
https://stackoverflow.com/questions/48011353/how-to-unwrap-the-type-of-a-promise
https://www.typescriptlang.org/docs/handbook/release-notes/typescript-4-5.html
The Awaited type is now built in to the language
*/
type T = Awaited<Promise<PromiseLike<number>> 
// number