/*
https://stackoverflow.com/questions/17382143/create-a-new-object-from-type-parameter-in-generic-class
To create a new object within generic code, you need to 
refer to the type by its constructor function. So 
instead of writing this:
*/
interface IActivatable {
    id: number;
    name:string;
}

class ClassA implements IActivatable {
    id: number;
    name: string;
}
/*
function activatorNotWorking<T extends IActivatable>(type: T): T {
    return new T(); // compile error could not find symbol T
}
*/
//need to write this:
function activator<T extends IActivatable>(type: { new(): T ;} ): T {
    return new type();
}

var classA: ClassA = activator(ClassA);
classA.id;
classA.name;



/*
Because the compiled JavaScript has all the type information erased, you 
can't use T to new up an object.
You can do this in a non-generic way by passing the type into the constructor.
*/
class TestOne {
    hi() {
        alert('Hi');
    }
}

class TestTwo {
    constructor(private testType) {

    }
    getNew() {
        return new this.testType();
    }
    getNewStr(s : string) {
        console.log(s);
        return new this.testType(s);
    }
    getNewNumber(n : number) {
        console.log(n);
        return new this.testType(n);
    }
}

var test = new TestTwo(TestOne);

var example = test.getNew();
example.hi();
var example1 = test.getNewStr('ha');
example1.hi();
var example2 = test.getNewNumber(10);
example2.hi();



{
//You could extend this example using generics to tighten up the types:
class TestBase {
    hi() {
        alert('Hi from base');
    }
}

class TestSub extends TestBase {
    hi() {
        alert('Hi from sub');
    }
}

class TestTwo<T extends TestBase> {
    constructor(private testType: new () => T) {
    }

    getNew() : T {
        return new this.testType();
    }
}

//var test = new TestTwo<TestBase>(TestBase);
var test2 = new TestTwo<TestSub>(TestSub);
var example3 = test2.getNew();
example3.hi();
}



/*
All type information is erased in JavaScript side and therefore you can't new up T, but I would 
prefer having typed parameter passed in to constructor:
*/
class A {
}

class B<T> {
    Prop: T;
    constructor(TCreator: { new (): T; }) {
        this.Prop = new TCreator();
    }
}

var test3 = new B<A>(A);
test3.Prop



/*
//can be adjusted a little by using
TCreator: new() => T
//instead of
//TCreator: { new (): T; }
//so the result should look like this
class A {
}

class B<T> {
    Prop: T;
    constructor(TCreator: new() => T) {
        this.Prop = new TCreator();
    }
}

var test = new B<A>(A);
*/



/*
I was trying to instantiate the generic from within a base class. 
None of the above examples worked for me as they required a concrete type in order to call the factory method.
this appears to work.

protected activeRow: T = {} as T;

 activeRow: T = {} <-- activeRow now equals a new object...

 as T; <-- As the type I specified. 

All together

export abstract class GridRowEditDialogBase<T extends DataRow> extends DialogBase{ 
    protected activeRow: T = {} as T;
}
*/
//That said, if you need an actual instance you should use:
export function getInstance<T extends Object>(type: (new (...args: any[]) => T), ...args: any[]): T {
      return new type(...args);
}

export class Foo {
  bar() {
    console.log("Hello World")
  }
}
getInstance(Foo).bar();

//If you have arguments, you can use.
export class Foo2 {
  constructor(public arg1: string, public arg2: number) {
  }

  m() {
    console.log(this.arg1);
    console.log(this.arg2);
  }
}
getInstance(Foo2, "Hi World", 2).m();
