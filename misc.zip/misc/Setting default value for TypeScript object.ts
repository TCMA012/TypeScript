//Setting default value for TypeScript object passed as argument
function sayName({ first, last = 'Smith' }: {first: string; last?: string }): void {
  const name = first + ' ' + last;
  console.log(name);
}

sayName({ first: 'Bob' });
/*
The trick is to first put in brackets what keys you want to pick from the argument object, 
with key=value for any defaults. 
Follow that with the : and a type declaration.

This is a little different than what you were trying to do, 
because instead of having an intact params object, you have instead have dereferenced variables.

If you want to make it optional to pass anything to the function, 
add a ? for all keys in the type, and 
add a default of ={} after the type declaration:
*/
function sayName2({first='Bob',last='Smith'}: {first?: string; last?: string}={}){
    var name = first + " " + last;
    console.log(name);
}

sayName2();