//convert a string to enum
enum Color{
    Red, Green
}

// To String
let green: string = Color[Color.Green];

// To Enum / number
let color : Color = Color[green];

let typedColor: Color = Color.Green;
let typedColorString: keyof typeof Color = "Green";

// if --noImplicitAny
let color2 : Color = Color[green as keyof typeof Color];
let color3: Color = (<any>Color)[green];
