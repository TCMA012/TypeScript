//The property 'value' does not exist on value of type 'HTMLElement'
//solution : <> is the casting operator
let inputValue = (<HTMLInputElement>document.getElementById(elementId)).value;