/*
Creating an object type with all function properties omitted
https://stackoverflow.com/questions/59148183/creating-an-object-type-with-all-function-properties-omitted?rq=3

filter the keys you need first and then pick the filtered keys from the original type:
*/
interface User {
  name: string;
  age: number;
  password: string;
  validatePassword(password: string): boolean;
}

type KeyNotOfType<T, V> = {
    [P in keyof T]-?: T[P] extends V ? never: P
}[keyof T]

type NoFunction<T> = Pick<T, KeyNotOfType<T, Function>>

type R = NoFunction<User>
//     name: string;
//     age: number;
//     password: string;
