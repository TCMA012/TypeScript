/*
https://stackoverflow.com/questions/76852941/using-literal-type-to-select-another-argument-type

It's fairly common to want a function that has several modes, and come to the conclusion that what you want is a generic function. 
However, often the way generic functions work with union types results in behaviour that's not what's desired.
*/
type MyKeyType = 'A' | 'B';

type MyTypeMap = {
    A: number,
    B: string,
};

// Just using declare since implementation details aren't important to the demo
declare function myFn<T extends MyKeyType>(type: T, data: MyTypeMap[T]): void;

myFn('A', 1); // Allowed
myFn('B', 'str'); // Allowed

// Allowed, but perhaps shouldn't be
myFn(
    Math.random() > 0.99 ? 'A' : 'B',
    'str'
);
/*
TypeScript Playground

As you can see, it's possible for a generic type to be inferred as a union type. 
When multiple arguments refer to the same generic type, it's possible for them to "mismatch". 
While it does follow the way the function's type signature has been defined, 
that may not describe how you as the author would like the function to work.

However, it is possible to tie the type of multiple function arguments together by defining them as a 
destructured tuple and using a discriminated union type.
*/

// Constructing a discrimated union automatically using an
// immediately indexed mapped type
type MyFnArgs = {
    [key in MyKeyType]: [type: key, data: MyTypeMap[key]];
}[MyKeyType]

// Just using declare since implementation details aren't important to the demo
declare function myFn(...args: MyFnArgs): void;

myFn('A', 1); // Allowed
myFn('B', 'str'); // Allowed

// No longer allowed
myFn(
    Math.random() > 0.99 ? 'A' : 'B',
    'str'
);
/*
TypeScript Playground

By using a labelled tuple it's possible to still have nice looking intellisense for your function too.

These examples have both used a return type of void. If you also need to associate your argument's type with a return type, then this method won't be enough for you.

It is possible to use function overloads to associate particular sets of parameters with particular return values, but it's also possible to introduce type errors with this approach, since overloads aren't checked for soundness:
*/
function myFn(type: 'A', data: number): number;
function myFn(type: 'B', data: string): string;
// TypeScript only checks the implementation signature allows for all overloads to be called
function myFn(type: MyKeyType, data: number | string): number | string {
    // But the implementation itself is only checked against the implementation details
    return Math.random() > 0.5 ? 1 : 'string';
}
/*
TypeScript Playground

Overloads also need to be constructed by hand, so depending on the size and complexity of your API this might not be a very appealing approach.

If TypeScript ever implements a oneof operator, to allow generics that don't permit the use of union types for their generic type, which would allow them to be narrowed within the body of the function in a way that can't be done currently, that might be useful in helping with approaches like this.

There are a few issues that have been around for several years asking for something like that, this is a reasonably popular one if you'd like to give it a 👍 react: Feature Request: "extends oneof" generic constraint; allows for narrowing type parameters

To expand a little, it is possible to use a similar approach of creating a discriminated union in order to create a function with a union type that has both arguments and return type defined.

However, when attempting to call a function with a union type in TypeScript, that union is converted into an intersection in order to ensure that any of the member's of the function's type could be called. This often results in an uncallable signature with arguments and/or a return type of never.

TypeScript 5.2 introduced a change that resolves this specifically for calling array methods, but that doesn't affect how it works with other functions: Easier Method Usage for Unions of Arrays

Since it's too long for a comment, a follow-up to @Giedrius's own answer as requested:

In order for your function to use generics in order to require arguments that correspond to type, then a column name that exists for that type, then a value of the correct type for that column, you would need to use two generic parameters and constrain the second one based on the first.
*/
{
type MyKeyType = 'account' | 'organization';

interface AccountColumns {
    name: string;
}

interface OrgnizationColumns {
    vatRate: number;
}

type MyTypeMap = {
    'account': AccountColumns,
    'organization': OrgnizationColumns,
};

// Just using declare since implementation details aren't important to the demo
declare function myFn<T extends MyKeyType, C extends keyof MyTypeMap[T]>(type: T, column: C, data: MyTypeMap[T][C]): void;

myFn('account', 'name', ""); // Allowed
myFn('organization', 'vatRate', ""); // Not allowed - vatRate is of type `number`
myFn('organization', 'vatRate', 3); // Allowed

myFn('account', 'vatRate', ""); // not allowed, because AccountColumns does not have property 'vatRate'
}
/*
TypeScript Playground

However, this still has the same drawbacks that I mentioned earlier in my answer regarding when generic types can be instantiated with unions. Something to be aware of, at the very least.

If you wanted to use the non-generic approach to get the same function signature, you could use a variation of the approach I described earlier as well. But it's slightly more complex to include the "data" type in the mapped type used to construct the discriminated union of tuples.

It involves iterating through all the column types, which means they need to be defined in a single interface. That means this won't work if your subtypes of column can have columns with the same name but different types.
*/
{
type MyKeyType = 'account' | 'organization';

interface Columns {
    name: string;
    vatRate: number;
}

type AccountColumns = Pick<Columns, 'name'>;
type OrgnizationColumns = Pick<Columns, 'vatRate'>;

type MyTypeMap = {
    'account': AccountColumns;
    'organization': OrgnizationColumns;
};

type MyFnArgs = {
    [type in MyKeyType]: [
        type: type,
        columns: keyof MyTypeMap[type],
        // Though this constraint is always fulfilled with the way we've defined the columns,
        // it's required in order to let TypeScript know it's safe to index `Columns` this way
        data: keyof MyTypeMap[type] extends keyof Columns
            ? Columns[keyof MyTypeMap[type]]
            : never,
    ];
}[MyKeyType];

// Just using declare since implementation details aren't important to the demo
declare function myFn(...args: MyFnArgs): void;

myFn('account', 'name', ""); // Allowed
myFn('organization', 'vatRate', ""); // Not allowed - vatRate is of type `number`
myFn('organization', 'vatRate', 3); // Allowed

myFn('account', 'vatRate', ""); // not allowed, because AccountColumns does not have property 'vatRate'
}
/*
TypeScript Playground

In this example, I've created a Columns interface and then extracted the subtypes of columns using the Pick utility type. 
However, if your column subgroups are already defined separately and you can't refactor them to be combined this way, 
then you may need to construct this interface in order to be able to iterate through it 
by converting a union of your column types into an intersection.

This example uses a simplified UnionToIntersection function which won't work with unions including boolean as a member 
because boolean is implemented as a union of true | false under the hood. 
But it will work for this purpose since we know we're just constructing an intersection of object types.

This conversion takes advantage of the fact that TypeScript treats the call signature of a union of function types 
as though it was an intersection of those types.
*/
{
//export 
type UnionToIntersection<U> = (
    U extends unknown ? (arg: U) => void : never
) extends (arg: infer I) => void ? I : never;

interface AccountColumns {
    'name': string;
}

interface OrgnizationColumns {
    'vatRate': number;
}

type MyTypeMap = {
    'account': AccountColumns;
    'organization': OrgnizationColumns;
};

type Columns = UnionToIntersection<MyTypeMap[keyof MyTypeMap]>;
}
//TypeScript Playground