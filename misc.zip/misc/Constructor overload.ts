/*
Constructor overload
https://stackoverflow.com/questions/12702548/constructor-overload-in-typescript
TypeScript allows you to declare overloads but you can only have one implementation and that implementation 
must have a signature that is compatible with all overloads. 
an optional parameter
*/
interface IBox {    
    x : number;
    y : number;
    height : number;
    width : number;
}
    
class Box {
    public x: number;
    public y: number;
    public height: number;
    public width: number;

    constructor(obj?: IBox) {    
        this.x = obj?.x ?? 0
        this.y = obj?.y ?? 0
        this.height = obj?.height ?? 0
        this.width = obj?.width ?? 0;
    }   
}

//or two overloads with a more general constructor
class Box2 {
    public x: number;
    public y: number;
    public height: number;
    public width: number;

    constructor();
    constructor(obj: IBox); 
    constructor(obj?: IBox) {    
        this.x = obj?.x ?? 0
        this.y = obj?.y ?? 0
        this.height = obj?.height ?? 0
        this.width = obj?.width ?? 0;
    }   
}
{
    const box0 = new Box();
    const box = new Box({x: 0, y: 87, width: 4, height: 0});
 
    const boxError = new Box({xx: 0, y: 87, width: 4, height: 0});
    const boxError2 = new Box({x: 0, yy: 87, width: 4, height: 0});
    const boxError3 = new Box({x: 0, y: 87, wwidth: 4, height: 0});
    const boxError5 = new Box({x: 0, y: 87, width: 4, hheight: 0});

    //Error!!!
    const boxError6 = new Box({y: 87, width: 4, height: 0});
    const boxError7 = new Box({x: 0, y: 87, width: 4});
}
{
    const box = new Box2({x: 0, y: 87, width: 4, height: 0});

    const boxError = new Box2({xx: 0, y: 87, width: 4, height: 0});
    const boxError2 = new Box2({x: 0, yy: 87, width: 4, height: 0});
    const boxError3 = new Box2({x: 0, y: 87, wwidth: 4, height: 0});
    const boxError5 = new Box2({x: 0, y: 87, width: 4, hheight: 0});

    //Error!!!
    const boxError6 = new Box2({y: 87, width: 4, height: 0});
    const boxError7 = new Box2({x: 0, y: 87, width: 4});
}
/*
Regarding constructor overloads one good alternative would be to 
implement the additional overloads as 
static factory methods. 
I think its more readable and easier than checking for all possible argument combinations at the constructor.

create a patient object using data from an insurance provider which stores values differently. 
To support yet another data structure for patient instantiation, one could simply 
add another static method to call the default constructor the best it can after normalizing the data provided.
*/
class Patient {
    static fromInsurance({
        first, middle = '', last,
        birthday, gender
    }: InsuranceCustomer): Patient {
        return new this(
            `${last}, ${first} ${middle}`.trim(),
            utils.age(birthday),
            gender
        );
    }

    constructor(
        public name: string,
        public age: number,
        public gender?: string
    ) {}
}

interface InsuranceCustomer {
    first: string,
    middle?: string,
    last: string,
    birthday: string,
    gender: 'M' | 'F'
}

const utils = {
    age: (birthdate: string) => {
        const { from, now } = utils.date
        const [by, bm, bd] = from(birthdate)
        const [ny, nm, nd] = now()
        
        if (ny == by) return 0

        let age = ny - by

        // If this year's birthday didn't came yet
        if (nm < bm || ((nm == bm) && (nd < bd))) age--
        
        return age
    },
    date: {
        now: () => utils.date.toArray(new Date()),
        from: (str: string) => utils.date.toArray(new Date(str)),
        toArray: (d: Date) => [d.getFullYear(), d.getMonth(), d.getDate()]
    }
};
{// Two ways of creating a Patient instance
    const
        jane = new Patient('Doe, Jane', 21),
        alsoJane = Patient.fromInsurance({ 
            first: 'Jane', last: 'Doe',
            birthday: 'Jan 1, 2000', gender: 'F'
        })

    console.clear()
    console.log(jane)
    console.log(alsoJane)

    const
    janeError = new Patient(21, 'Doe, Jane'),
    alsoJaneError = Patient.fromInsurance({ 
        first: 21, last: 'Doe',
        birthday: 'Jan 1, 2000', gender: 'F'
    })
}



/*
It sounds like you want the object parameter to be optional, and also each of the properties in the object to be optional. 
In the example, as provided, overload syntax isn't needed. 
I wanted to point out some bad practices in some of the answers here. 
Granted, it's not the smallest possible expression of essentially writing box = { x: 0, y: 87, width: 4, height: 0 }, 
but this provides all the code hinting niceties you could possibly want from the class as described. 
This example allows you to call a function with one, some, all, or none of the parameters and still get default values.
*/
 /** @class */
 class Box3 {
     public x?: number;
     public y?: number;
     public height?: number;
     public width?: number;   

     // The Box3 class can work double-duty as the interface here since 
     // they are identical.  If you choose to add methods or modify this class, 
     // you will need to define and reference a new interface 
     // for the incoming parameters object 
     // e.g.:  `constructor(params: Box3ObjI = {} as Box3ObjI)` 
     constructor(params: Box3 = {} as Box3) {

         // Define the properties of the incoming `params` object here. 
         // Setting a default value with the `= 0` syntax is optional for each parameter
         const {
             x = 0,
             y = 0,
             height = 1,
             width = 1
         } = params;
         
         //  If needed, make the parameters publicly accessible
         //  on the class ex.: 'this.var = var'.
         /**  Use jsdoc comments here for inline ide auto-documentation */
         this.x = x;
         this.y = y;
         this.height = height;
         this.width = width;
     }
}
/*
Need to add methods - A verbose but more extendable alternative: 
The Box3 class above can work double-duty as the interface since they are identical. 
If you choose to modify the above class, you will need to 
define and reference a new interface for the incoming parameters object 
since the Box3 class no longer would look exactly like the incoming parameters. 
Notice where the question marks (?:) denoting optional properties move in this case. 
Since we're setting default values within the class, they are guaranteed to be present, 
yet they are optional within the incoming parameters object:
*/
{
interface Box3Params {
    x?: number;
        // Add Parameters ...
}

class Box3 {
        public x: number;
        // Copy Parameters ...
        constructor(params: Box3Params = {} as Box3Params) {
        let { x = 0 } = params;
        this.x = x;
}
doSomething = () => {
    return this.x + this.x;
    }
}
}
/*
Whichever way you choose to define your class, this technique offers the guardrails of type safety, 
yet the flexibility write any of these:
*/
const box1 = new Box3();
const box2 = new Box3({});
const box3 = new Box3({x: 0});
const box4 = new Box3({x: 0, height: 10});
const box5 = new Box3({x: 0, y: 87, width: 4, height: 0});

//NOT Error!!!
const box6 = new Box3({y: 87, width: 4, height: 0});
const box7 = new Box3({x: 0, y: 87, width: 4});

// Correctly reports error in TypeScript, and in js, box6.z is undefined
const boxError6 = new Box3({z: 0});  
const boxError7 = new Box3({xx: 0, yy: 87, wwidth: 4, height: 0});
const boxError8 = new Box3({x: 0, yy: 87, wwidth: 4, height: 0});
const boxError9 = new Box3({x: 0, y: 87, wwidth: 4, height: 0});
const boxError10 = new Box3({x: 0, y: 87, width: 4, hheight: 0});


{
//use Partial
class BoxPartial {
   x: number;
   y: number;
   height: number;
   width: number;

   public constructor(b: Partial<BoxPartial> = {}) {
      Object.assign(this, b);
   }
}

// Example use
const a = new BoxPartial();
const b = new BoxPartial({x: 10, height: 99});
const ok = new BoxPartial({x: 0, y: 87, width: 4, height: 0});
const c = new BoxPartial({foo: 10});          //  fail to compile

//NOT Error!!!
const d = new BoxPartial({y: 87, width: 4, height: 0});
const e = new BoxPartial({x: 0, y: 87, width: 4});

const box6 = new BoxPartial({z: 0});  
const box7 = new BoxPartial({xx: 0, yy: 87, wwidth: 4, height: 0});
}


/*
The main use case for method overloading is probably 
writing declarations for libraries that have magic arguments in their API. 
Since all the heavy-lifting of handling different sets of possible arguments is done by you 
I don't see much advantage in using overloads rather than ad-hoc methods for each scenario.

using es6/typescript destructured object can be 15-90% faster than Object.assign. 
Using a destructured parameter only allows methods and properties you've assigned to the object.
*/