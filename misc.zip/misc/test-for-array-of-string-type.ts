/*
https://stackoverflow.com/questions/23130292/test-for-array-of-string-type-in-typescript

You cannot test for string[] in the general case but you can test for Array quite easily the same as in 
JavaScript https://stackoverflow.com/a/767492/390330
I prefer 
Array.isArray(value)

If you specifically want for string array you can do something like:
*/
const fruits = ["Banana", "Orange", "Apple", "Mango"];
let result = Array.isArray(fruits);
console.log('result', result)
let value = fruits
class MyClassName {
}
let items : any = ["Banana", "Orange", "Apple", "Mango"];

if (Array.isArray(value)) {
   var somethingIsNotString = false;
   value.forEach(function(item){
      if(typeof item !== 'string'){
         somethingIsNotString = true;
      }
   })
   if(!somethingIsNotString && value.length > 0){
      console.log('string[]!');
   }
}
//In case you need to check for an array of a class (not a basic type)
if(items && (items.length > 0) && (items[0] instanceof MyClassName))
//If you are not sure that all items are same type
items.every(it => it instanceof MyClassName)


typescript every( instanceof 
typescript ".every(" instanceof 