/*
https://stackoverflow.com/questions/43118692/typescript-filter-out-nulls-from-an-array
filter out nulls from an array
You can use a type predicate function in the .filter to avoid opting out of strict type checking:
*/
function notEmpty<TValue>(value: TValue | null | undefined): value is TValue {
    return value !== null && value !== undefined;
}

const array: (string | null)[] = ['foo', 'bar', null, 'zoo', null];
const filteredArray: string[] = array.filter(notEmpty);
//Alternatively you can use array.reduce<string[]>(...).



//stricter predicates
/*
While this solution works in most scenarios, you can get a more rigorous type check in the predicate. 
As presented, the function notEmpty does not actually guarantee that it identifies correctly 
whether the value is null or undefined at compile time. 
For example, try shortening its return statement down to return value !== null;, 
and you'll see no compiler error, even though the function will incorrectly return true on undefined.

One way to mitigate this is to constrain the type first using control flow blocks, and then to 
use a dummy variable to give the compiler something to check. 
In the example below, the compiler is able to infer that the value parameter cannot be a null or undefined by the time 
it gets to the assignment. 
However, if you remove || value === undefined from the if condition, you will see a compiler error, 
informing you of the bug in the example above.
*/
function notEmptyStricterPredicate<TValue>(value: TValue | null | undefined): value is TValue {
  if (value === null || value === undefined) return false;
  const testDummy: TValue = value;
  return true;
}
/*
A word of caution: there exist situations where this method can still fail you. 
Be sure to be mindful of issues associated with contravariance.
*/



const nonNull = array.filter((e): e is Exclude<typeof e, null> => e !== null)
console.log(nonNull);



type MyType = string;
array.filter((x): x is MyType => x !== null);



const arr = ["a", null, "b", "c"];
// string[]
const stringsOnly = arr.flatMap(f => f ? [f] : []);

//???
const nonNullOnly = array.flatMap(f => f ? [f] : []);
console.log(nonNullOnly);
//???


const filteredArray2: string[] = array.filter((s): s is string => Boolean(s));



function notEmptyNonNullable<TValue>(value: TValue): value is NonNullable<TValue> {
    return value !== null && value !== undefined;
}
const array3: (string | null | undefined)[] = ['foo', 'bar', null, 'zoo', undefined];

const filteredArray3: string[] = array3.filter(notEmptyNonNullable);
console.log(filteredArray3) 
// ["foo", "bar", "zoo"]