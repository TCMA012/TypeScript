/*
https://stackoverflow.com/questions/39672807/types-in-object-destructuring
https://mariusschulz.com/blog/typing-destructured-object-parameters-in-typescript
*/
const {foo}: {foo: IFoo[]} = bar;
//or
const foo: IFoo[] = bar.foo;