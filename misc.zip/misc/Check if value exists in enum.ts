/*
Check if value exists in enum in TypeScript

use Object.values(ENUM).includes(ENUM.value) because string enums are not reverse mapped, according to 
https://www.typescriptlang.org/docs/handbook/release-notes/typescript-2-4.html:
*/
enum Vehicle {
    Car = 'car',
    Bike = 'bike',
    Truck = 'truck'
}
/*
becomes:
{
    Car: 'car',
    Bike: 'bike',
    Truck: 'truck'
}
*/
//if (Object.values(Vehicle).includes('car')) {
if (Object.values(Vehicle).includes(Vehicle.Car)) {
    console.log('Object.values(Vehicle)',Object.values(Vehicle));
}

let typev = Vehicle.Bike
Object.values(Vehicle).includes(typev as Vehicle)
/*
If you get an error for: Property 'values' does not exist on type 'ObjectConstructor', 
then you are not targeting ES2017. 
use this tsconfig.json config:
"compilerOptions": {
    "lib": ["es2017"]
}
*/
//This works only on non-const, number-based enums.
export enum MESSAGE_TYPE {
    INFO = 1,
    SUCCESS = 2,
    WARNING = 3,
    ERROR = 4,
};
let type = 3;
if (type in MESSAGE_TYPE) {
    console.log('type',type)
}