/*
https://www.typescriptlang.org/docs/handbook/utility-types.html#recordkeys-type
https://stackoverflow.com/questions/51936369/what-is-the-record-type
A Record<K, T> is an object type whose property keys are K and whose property values are T. 

keyof Record<K, T> is equivalent to K
Record<K, T>[K] is (basically) equivalent to T.

K purpose: to limit the property keys to particular values. 
If you want to accept all possible string-valued keys, you could do something like Record<string, T>, 
but the idiomatic way of doing that is to use an index signature like { [k: string]: T }.

Does the K generic forbid additional keys on the object that are not K, or 
does it allow them and just indicate that their properties are not transformed to T?
It doesn't exactly "forbid" additional keys: after all, 
a value is generally allowed to have properties not explicitly mentioned in its type... 
but it wouldn't recognize that such properties exist:
*/
declare const x: Record<"a", string>;
x.b; // error, Property 'b' does not exist on type 'Record<"a", string>'
//and it would treat them as excess properties which are sometimes rejected:

declare function acceptR(x: Record<"a", string>): void;
acceptR({a: "hey", b: "you"}); // error, Object literal may only specify known properties

//and sometimes accepted:
const y = {a: "hey", b: "you"};
acceptR(y); // okay

type ThreeStringProps = Record<'prop1' | 'prop2' | 'prop3', string>
//Is exactly the same as:
type ThreeStringProps2 = {prop1: string, prop2: string, prop3: string}



/*
A Record lets you create a new type from a Union. The values in the Union are used as attributes of the new type.
*/
type CatNames = "miffy" | "boris" | "mordred";
/*
create an object that contains information about all the cats, 
create a new type using the values in the CatNames union as keys.
*/
type CatList = Record<CatNames, {age: number}>
//create an object:
const cats: CatList = {
  miffy: { age:99 },
  boris: { age:16 },
  mordred: { age:600 }
}
/*
strong type safety:
If I forget a cat, I get an error.
If I add a cat that's not allowed, I get an error.
If I later change CatNames, I get an error. This is especially useful because CatNames is likely imported from another file, and 
likely used in many places.
*/
class Result<Properties = Record<string, any>> {
  constructor(
    public readonly properties: Record<
      keyof Properties,
      Properties[keyof Properties]
    >
  ) { }
}

interface CourseInfo {
  title: string
  professor: string
  cfu: number
}

const course = new Result<Record<string, any>>({
  title: "Literature",
  professor: "Mary Jane",
  cfu: 12
})

console.log(course.properties.title)
//console.log(course.properties.students)     <- this does not compile!


const course2 = new Result({
  title2: "Literature2",
  professor2: "Mary Jane2",
  cfu2: 120
})

console.log(course2.properties.title2)
//console.log(course.properties.students)     <- this does not compile!




/*
Real-world React example.
Create a Status component. 
The component would receive a status prop, and then render an icon. I've simplified the code quite a lot here for illustrative purposes

I had a union like this:
*/
type Statuses = "failed" | "complete";
type IconTypes = string;
type IconColors = string;

const icons: Record<
  Statuses,
  { iconType: IconTypes; iconColor: IconColors }
> = {
  failed: {
    iconType: "warning",
    iconColor: "red"
  },
  complete: {
    iconType: "check",
    iconColor: "green"
  }
};

// render by destructuring an element from the object into props:
//const Status = ({status}) => <Icon {...icons[status]} />
/*
If the Statuses union is later extended or changed, 
I know my Status component will fail to compile and I'll get an error that I can fix immediately. 
This allows me to add additional error states to the app.

Note that the actual app had dozens of error states that were referenced in multiple places, 
so this type safety was extremely useful.
*/