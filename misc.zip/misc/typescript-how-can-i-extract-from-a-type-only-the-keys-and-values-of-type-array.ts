/*
extract from a type only the keys and values of type array
https://stackoverflow.com/questions/68431886/typescript-how-can-i-extract-from-a-type-only-the-keys-and-values-of-type-array

extract only the properties from an object whose value is an array.

type Person = {
   name: string
   addresses: Address[]
   age: number
   phoneNumbers: PhoneNumber[]
}

PullOutArrays<Person> => {
   phoneNumbers: PhoneNumber[]
   addresses: Address[]
}
*/
type FilteredKeys<T, U> = { [P in keyof T]: T[P] extends U ? P : never }[keyof T];

type FilteredProperties<T, U> = { [K in FilteredKeys<T, U>]: T[K]; };

type PullOutArrays<T> = FilteredProperties<T, unknown[]>;

type Person = {
  name: string
  addresses: string[]
  age: number
  phoneNumbers: number[]
}

type PersonKeys = FilteredKeys<Person, unknown[]>;
// "addresses" | "phoneNumbers"

type PersonArrays = PullOutArrays<Person>;
// {
//    addresses: string[];
//    phoneNumbers: number[];
// }
/*
As you may have seen from your original attempt, what you end up with after mapping the conditional:

{ [P in keyof T]: T[P] extends U ? P : never }
Is an interface containing all the property keys, but with the non-array types changed to never, 
apparently because TS does not initially check what the types assigned to property keys are. 
By adding an index on the end, you force the compiler to read the value of the property and ultimately omit it from the result.

Using the union which is generated, you can then create a new mapped type from that union on the original interface.
*/



//TS 4.1+, a more direct approach could be to remove keys by asserting the key as never based on the value type:

type OnlyArraysPerson = {
  [K in keyof Person as Person[K] extends unknown[] ? K : never]: Person[K]
}
//To be more generic:
type OnlyArrays<T> = {
 [K in keyof T as T[K] extends unknown[] ? K : never]: T[K]
}

type ArrayPerson = OnlyArrays<Person>