//https://stackoverflow.com/questions/13212521/typescript-static-classes
//You cannot instantiate an abstract class.
export abstract class MyClass {         
    public static myProp = "Hello";

    public static doSomething(): string {
      return "World";
    }
}

const okay = MyClass.doSomething();
MyClass.myProp;
//const errors = new MyClass(); // Error