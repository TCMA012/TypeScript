//https://stackoverflow.com/questions/12687779/how-do-you-produce-a-d-ts-typings-definition-file-from-an-existing-javascript
https://github.com/DefinitelyTyped/DefinitelyTyped
https://microsoft.github.io/TypeSearch/
which is a search engine for NPM-published .d.ts files; this will have slightly more definitions than DefinitelyTyped.