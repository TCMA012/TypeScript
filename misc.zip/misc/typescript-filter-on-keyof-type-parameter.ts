/*
Filter on keyof type parameter
https://stackoverflow.com/questions/61506794/typescript-filter-on-keyof-type-parameter

dynamically find the keys of a certain type and use them to produce an other object.

I have a Detail object and want to use it to dynamically generate a Column object only based on the properties of type Desc. 
*/
// Model
interface Desc {
    creationDate: Date;
}

interface Address extends Desc {
    zipCode: number;
    adressName: string;
}

interface Order extends Desc {
    id: number;
    orderName: string;
}

interface Detail {
    name: string;
    address: Address[];
    orders: Order[];
}
// Table column configuration
interface Column<T> {
    field: keyof T;
    active: boolean;
}

type ColumnConfig0<T> = { [P in keyof T]: Column<T[P] extends Desc ? P : never>[] };

const config: ColumnConfig0<Detail> = {
    address: [
        {
            field: "zipCode",
            active: true 
        }, 
        {
            field: "addressName",
            active: true
        }
    ],
    order: [
        {
            field: "id",
            active:false
        },
        {
            field: "orderName",
            active: false
        }
    ],
    // Detail.name should not be available but it is

}
//construct my config object and thus be able to detect any errors if my Detail object changes
/*
In order to exclude some columns for a mapped type, we need to use an 
intermediate helper type, allowing us to select only the keys respecting our condition, T[K] extends Desc:
*/
type ConfigurableColumnsKeys<T extends object> = {
  [K in keyof T]: T[K] extends Desc ? K : never
}[keyof T];
//Given this, ColumnConfig just need to map over this generic type instead of the original keyof T:

type ColumnConfig<T extends object> = {
  [P in ConfigurableColumnsKeys<T>]: Column<P>[] 
};
//Then your config object will be correctly validated:

  // Error
  name: [
    { field: 'abc', active: true }
  ]
/*
If you need to allows arrays too (i.e. Address[] instead of Address), you can 
change the helper type, checking for T extends Desc[]. 
Furthermore, you will need an UnboxArray helper too, to extract item value Order[] -> Order for your column config:
*/
type ConfigurableColumnsKeysArray<T extends object> = {
  [K in keyof T]: T[K] extends Desc ? K : T[K] extends Desc[] ? K : never
}[keyof T];

type UnboxArray<T> = T extends Array<infer V> ? V : T;

type ColumnConfigArray<T extends object> = {
  [P in ConfigurableColumnsKeysArray<T>]: Column<UnboxArray<T[P]>>[]
};