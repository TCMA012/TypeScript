/*
https://stackoverflow.com/questions/30734509/how-to-pass-optional-parameters-while-omitting-some-other-optional-parameters
pass optional parameters while omitting some other optional parameters
call the function error() not specifying the title parameter, but setting autoHideAfter to say 1000
use undefined:
*/
export interface INotificationService {
    error(message: string, title?: string, autoHideAfter? : number);
}

class X {
    error(message: string, title?: string, autoHideAfter?: number) {
        console.log(message, title, autoHideAfter);
    }
}

new X().error("hi there", undefined, 1000);
new X().error("hi there", 1000, undefined);



//change your params to be an interface:
export interface IErrorParams {
  message: string;
  title?: string;
  autoHideAfter?: number;
}
/*
export interface INotificationService {
  error(params: IErrorParams);
}
*/
class Y {
    error(params: IErrorParams): void {
    }
}
new Y().error({message: 'msg', autoHideAfter: 42});



class Z {
    error(message: string, options?: {title?: string, autoHideAfter?: number}): void {
    }
}
//omit the title parameter:
new Z().error('the message', { autoHideAfter: 1 })
//this allows me to add more parameter without having to send the others

//use Partial<T> type in method's signature but it this case you have to create an interface for your options:
interface IMyOptions {
  title: string;
  autoHideAfter: number;
}
class C {
    error(message: string, options?: Partial<IMyOptions>): void {
    }
}
new C().error('the message', { autoHideAfter: 1 })



//only pass optional parameters in an object. (And also make params object optional).???
export interface IErrorParams {
  title?: string;
  autoHideAfter?: number;
}

//export interface INotificationService {
class D {
    // make params optional so you don't have to pass in an empty object
    // in the case that you don't want any extra params
    error(message: string, params?: IErrorParams): void {
    }
}

// all of these will work as expected???
new D().error('A message with some params but not others:', {autoHideAfter: 42});
new D().error('Another message with some params but not others:', {title: 'StackOverflow'});
new D().error('A message with all params:', {title: 'StackOverflow', autoHideAfter: 42});
new D().error('A message with all params, in a different order:', {autoHideAfter: 42, title: 'StackOverflow'});
new D().error('A message with no params at all:');



//specify multiple method signatures on the interface then have multiple method overloads on the class method: ???
interface INotificationService2 {
    error(message: string, title?: string, autoHideAfter?: number);
    error(message: string, autoHideAfter: number);
}

class MyNotificationService implements INotificationService2 {
    error(message: string, title?: string, autoHideAfter?: number);
    error(message: string, autoHideAfter?: number);
    error(message: string, param1?: (string|number), param2?: number) {
        var autoHideAfter: number,
            title: string;

        // example of mapping the parameters
        if (param2 != null) {
            autoHideAfter = param2;
            title = <string> param1;
        }
        else if (param1 != null) {
            if (typeof param1 === "string") {
                title = param1;
            }
            else {
                autoHideAfter = param1;
            }
        }

        // use message, autoHideAfter, and title here
    }
}

var service: INotificationService = new MyNotificationService();
service.error("My message");
service.error("My message", 1000);
service.error("My message", "My title");
service.error("My message", "My title", 1000);
