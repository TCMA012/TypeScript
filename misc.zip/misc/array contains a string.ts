//check whether an array contains a string
//Array.prototype.indexOf():
let channelArray: Array<string> = ['one', 'two', 'three'];
console.log(channelArray.indexOf('three') > -1);

// ECMAScript 2016 Array.prototype.includes():
console.log(channelArray.includes('three'));

//an array of objects
const arr = [{foo: 'bar'}, {foo: 'bar'}, {foo: 'baz'}];
console.log(arr.find(e => e.foo === 'bar')); // {foo: 'bar'} (first match)
console.log(arr.some(e => e.foo === 'bar')); // true
console.log(arr.filter(e => e.foo === 'bar')); // [{foo: 'bar'}, {foo: 'bar'}]