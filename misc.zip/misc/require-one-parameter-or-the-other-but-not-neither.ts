//https://stackoverflow.com/questions/52132696/typescript-require-one-parameter-or-the-other-but-not-neither
export type Opts0 = { path: string | Array<string> } | { paths: string | Array<string> }


//or
type StringOrArray = string | Array<string>;

type PathOpts  = { path : StringOrArray };
type PathsOpts = { paths: StringOrArray };

export type Opts1 = PathOpts | PathsOpts;



/*
If you already have that interface defined and want to avoid duplicating the declarations, 
an option could be to create a conditional type that takes a type and 
returns a union with each type in the union containing one field 
(as well as a record of never values for any other fields to dissalow any extra fields to be specified)

We will use the distributive property of conditional types to in effect iterate over all keys of the T type. 
The distributive property needs an extra type parameter to work and we 
introduce TKey for this purpose but we also 
provide a default of all keys since we want to take all keys of type T.

Take each key of the original type and 
create a new mapped type containing just that key. 
The result will be a union of all the mapped types that contain a single key. 
The mapped type will remove the optionality of the property (the -?, described here) and 
the property will be of the same type as the original property in T (T[TKey]).

The last part is Partial<Record<Exclude<keyof T, TKey>, never>>. 
Because of how excess property checks on object literals work we can 
specify any field of the union in an object key assigned to it. 
That is for a union such as 
{ path: string | Array<string> } | { paths: string | Array<string> } 
we can assign this object literal { path: "", paths: ""} which is unfortunate. 
The solution is to require that 
if any other properties of T (other then TKey so we get Exclude<keyof T, TKey>) are present in the object literal 
for any given union member 
they should be of type never (so we get Record<Exclude<keyof T, TKey>, never>>). 
But we don't want to have to explicitly specify never for all members so that is why we 
Partial the previous record.
*/
export interface Opts {
    paths?: string | Array<string>,
    path?: string | Array<string>
}

type EitherField<T, TKey extends keyof T = keyof T> =
    TKey extends keyof T ? { [P in TKey]-?:T[TKey] } & Partial<Record<Exclude<keyof T, TKey>, never>>: never
export const foo = (o: EitherField<Opts>) => {};
foo({ path : '' });
foo({ paths: '' });
foo({ path : '', paths:'' }); // error
foo({}) // error
//exactly one