//You can make use of the typed dictionary by splitting your example up in declaration and initialization:
interface IPerson {
    firstName: string;
    lastName: string;
}
 
var persons: { [id: string] : IPerson; } = {};
persons["p1"] = { firstName: "F1", lastName: "L1" };
persons["p2"] = { firstName: "F2" }; // will result in an error



interface Dictionary<T> {
    [Key: string]: T;
}

export class SearchParameters {
    SearchFor: Dictionary<string> = {};
}
/*
getUsers2(): Observable<any> {
        var searchParams = new SearchParameters();
        searchParams.SearchFor['userId'] = '1';
        searchParams.SearchFor['userName'] = 'xyz';

        return this.http.post(searchParams, 'users/search')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));
    }
*/



let dictionary= new Map<string, string>();
dictionary.set("key", "value");
dictionary.get("key");
dictionary.delete("key");
dictionary.clear(); //Removes all key-value pairs






const marks: Record<string, string> = {};
marks['Geography'] = '25';
marks['Maths'] = '40';
marks['English'] = '31';
console.log(marks);




let map2 = new Map<string, string>([
    ["key1", "value1"],
    ["key2", "value2"]
]);
console.log(map2);



const marks2 = new Map<string, number>();
marks2.set('History', 39);
marks2.set('Geography', 25);
marks2.set('Maths', 40);
console.log(marks2);



let map = new Map([
    [
        "api/service/method",
        {
            uriPath: {}
        }
    ],
    [
        "\"type\": \"html\"",
        {
            body: {}
        }
    ]
]);

console.log(map);
console.log(map.get('api/service/method'));
console.log(map.get('"type": "html"'));