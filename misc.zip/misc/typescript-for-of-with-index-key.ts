//https://stackoverflow.com/questions/36108110/typescript-for-of-with-index-key
const someArray = [90, 20, 50];
someArray.forEach((value, index) => {
    console.log(index); // 0, 1, 2
    console.log(value); // 90, 20, 50
});
//But if you want the abilities of for...of, then you can map the array to the index and value:
for (const { index, value } of someArray.map((value, index) => ({ index, value }))) {
    console.log(index); // 0, 1, 2
    console.log(value*10); // 900, 200, 500
}

for (const [key, value] of someArray.entries()) {
    console.log(key); // 0, 1, 2
    console.log(value*1000); // 90000, 20000, 50000
}

//That's a little long, so it may help to put it in a reusable function:
function toEntries<T>(a: T[]) {
    return a.map((value, index) => [index, value] as const);
}

for (const [index, value] of toEntries(someArray)) {
    console.log(index); // 0, 1, 2
    console.log(value*100); // 9000, 2000, 5000
}

/*
Iterable Version
This will work when targeting ES3 or ES5 if you compile with the --downlevelIteration compiler option.
function* toEntries_yield<T>(values: T[] | IterableIterator<T>) {
    let index = 0;
    for (const value of values) {
        yield [index, value] as const;
        index++;
    }
}
*/