/*
convert a string to number
https://stackoverflow.com/questions/14667713/how-to-convert-a-string-to-number-in-typescript
use the unary + operator
*/
+'123';

parseInt('123', 10)     // 123
parseInt('1101', 2)     // 13
parseInt('0xfae3', 16)  // 64227
parseFloat('123.45')

Number('1234') // 1234
Number('9BX9') // NaN

/*
Angular:
Within a template, Number(x) and parseInt(x) throws an error, and +x has no effect. 
Valid casting will be x*1 or x/1.
""*1 returns 0 unfortunately
*/