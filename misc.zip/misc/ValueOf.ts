/*
Looks like the question title attracts people looking for 
a union of all possible property value types, 
analogous to the way keyof gives you the union of all possible property key types. 
You can make a 
ValueOf analogous to keyof, by using 
indexed access types with keyof T as the key:
*/
type ValueOf<T> = T[keyof T];

type Foo = { a: string, b: number };
type ValueOfFoo = ValueOf<Foo>; // string | number

// type TEST1 = boolean | 42 | "heyhey"
type TEST1 = ValueOf<{ foo: 42, sort: 'heyhey', bool: boolean }>
// type TEST2 = 1 | 4 | 9 | "zzz..."
type TEST2 = ValueOf<[1, 4, 9, 'zzz...']>



/*
assign an object property to a value given a key and value as inputs yet still be able to determine the type of the value.
use individual keys, narrower than keyof T, to extract just the value type you care about:
*/
type sameAsString = Foo['a']; // look up a in Foo
type sameAsNumber = Foo['b']; // look up b in Foo
/*
to make sure that the key/value pair "match up" properly in a function, you should 
use generics as well as indexed access types:
*/
type JWT = { id: string, token: string, expire: Date };
const obj: JWT = { id: 'abc123', token: 'tk01', expire: new Date(2018, 2, 14) };

function print(key: keyof JWT) {
    switch (key) {
        case 'id':
        case 'token':
            console.log(obj[key].toUpperCase());
            break;
        case 'expire':
            console.log(obj[key].toISOString());
            break;
    }
}

/*
function onChange(key: keyof JWT, value: any) {
    switch (key) {
        case 'id':
        case 'token':
            obj[key] = value + ' (assigned)';
            break;
        case 'expire':
            obj[key] = value;
            break;
    }
}
*/
declare function onChange<K extends keyof JWT>(key: K, value: JWT[K]): void; 
onChange('id', 'def456'); // okay
onChange('expire', new Date(2018, 3, 14)); // okay
onChange('expire', 1337); // error. 1337 not assignable to Date
/*
the key parameter allows the compiler to infer the generic K parameter. 
Then it requires that value matches JWT[K], the indexed access type you need.
*/



//to extract the union type of the object, thanks to the const assertions (as const part):
const myObj = {
    a: 1,
    b: 'some_string'
} as const;

type Values = typeof myObj[keyof typeof myObj];
//1 | "some_string"



//limit the value to be the one for that particular key.
function setAttribute<T extends Object, U extends keyof T>(obj: T, key: U, value: T[U]) {
    obj[key] = value;
}

interface Pet {
     name: string;
     age: number;
}

const dog: Pet = { name: 'firulais', age: 8 };

setAttribute(dog, 'name', 'peluche') // Works
setAttribute(dog, 'name', 100)       // Error (number is not string)
setAttribute(dog, 'age', 2)          // Works
setAttribute(dog, 'lastname', '')    // Error (lastname is not a property)