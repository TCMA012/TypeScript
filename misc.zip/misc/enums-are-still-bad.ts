/*
https://graphqleditor.com/blog/enums-are-still-bad/
if you don't need access to the values in your enum just use a union type, if you do just get them into a list in a const and you can do whatever you need from there, without ever bothering with enums at all.
ignore enum altogether.
*/
const PkmnTypes = ['fire', 'grass', 'lightning', 'water'] as const;

type PkmnType = (typeof PkmnTypes)[number];

type Pkmn = {
  pkmnType: PkmnType;
};

const Charizard: Pkmn = {
  pkmnType: 'fire',
};

const Charizard2: Pkmn = {
  pkmnType: 'fire2',
};

console.log(Charizard)