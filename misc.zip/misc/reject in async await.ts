/*
https://stackoverflow.com/questions/42453683/how-to-reject-in-async-await-syntax
reject in async/await
throw an Error wrapping the value, which results in a rejected promise with an Error wrapping the value:
*/
} catch (error) {
    throw new Error(400);
}
//just throw the value, but then there's no stack trace information:
} catch (error) {
    throw 400;
}
//Alternately, return a rejected promise with an Error wrapping the value, but it's not idiomatic:
} catch (error) {
    return Promise.reject(new Error(400));
}
/*
(Or just return Promise.reject(400);, but again, then there's no context information.)
as you're using TypeScript and foo's return value is Promise<A>:
*/
return Promise.reject<A>(400 /*or Error*/ );
/*
In an async/await situation, that last is probably a bit of a semantic mis-match, but it does work.
If you throw an Error, that plays well with anything consuming your foo's result with await syntax:
*/
try {
    await foo();
} catch (error) {
    // Here, `error` would be an `Error` (with stack trace, etc.).
    // Whereas if you used `throw 400`, it would just be `400`.
}