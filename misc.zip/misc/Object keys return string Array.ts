/*
https://stackoverflow.com/questions/52856496/typescript-object-keys-return-string
When using Object.keys(obj), the return value is a string[], whereas I want a (keyof obj)[].

Object.keys returns a string[]. This is by design as described in this issue
https://github.com/Microsoft/TypeScript/issues/12870
This is intentional. Types in TS are open ended. So keysof will likely be less than all properties you would get at runtime.

since you can add more properties to any object to JS, the keyof operator will not return the same things as Objects.keys.

https://github.com/Microsoft/TypeScript/pull/12253
My reservations about Object.keys returning (keyof T)[] still hold. 
It makes sense only in the domain of type variables (i.e. T and keyof T). 
Once you move to the instantiated type world it degenerates 
because an object can (and often does) have more properties at run-time than are statically known at compile time. 
For example, imagine a type Base with just a few properties and a family of types derived from that. 
Calling Object.keys with a Base would return a (keyof Base)[] which is 
almost certainly wrong 
because an actual instance would be a derived object with more keys. 
It completely degenerates for type {} which could be any object but would return never[] for its keys.

BTW, I have the same reservations about Object.entries which I notice is now typed this way.

Note that the changes we made to for-in specifically apply only when objects have a type parameter type. 
In for (let x in obj) ... where obj is of type T, 
if T is a type parameter we infer keyof T for x, 
but otherwise we infer type string. 
To do the same for Object.keys would require some way to constrain a type argument to only be type parameter,
 which currently isn't possible.

There are several solution, the simplest one is to just use a type assertion:
*/
const v0 = {
    a: 1,
    b: 2
};

var values = (Object.keys(v0) as Array<keyof typeof v>).reduce((accumulator, current) => {
    accumulator.push(v[current]);
    return accumulator;
}, [] as (typeof v[keyof typeof v])[]);

//You can also create an alias for keys in Object that will return the type you want:
export const v = {
    a: 1,
    b: 2
};

declare global {
    interface ObjectConstructor {
        typedKeys<T>(obj: T): Array<keyof T>
    }
}
Object.typedKeys = Object.keys as any

var values2 = Object.typedKeys(v).reduce((accumulator, current) => {
    accumulator.push(v[current]);
    return accumulator;
}, [] as (typeof v[keyof typeof v])[]);



/*
Use type assertion only if you know that your object doesn't have extra properties 
(such is the case for an object literal but not an object parameter).
Explicit assertion
*/
let obj;
Object.keys(obj) as Array<keyof typeof obj>
//Hidden assertion
const getKeys = Object.keys as <T extends object>(obj: T) => Array<keyof T>
/*
Use getKeys instead of Object.keys. getKeys is a ref to Object.keys, but the return is typed literally.

One of TypeScript’s core principles is that type checking focuses on the shape that values have. (reference)
*/
interface SimpleObject {
   a: string 
   b: string 
}

const x = {
   a: "article", 
   b: "bridge",
   c: "Camel" 
}
/*
x qualifies as a SimpleObject because it has it's shape. 
This means that when we see a SimpleObject, we know that 
it has properties a and b, but it might have additional properties as well.
*/
const someFunction = (obj: SimpleObject) => {
    Object.keys(obj).forEach((k)=>{
        //..
    })
}
/*
someFunction(x)
if by default we would type Object.keys as desired by the OP "literally":

We would get that typeof k is "a"|"b". 
When iterating the actual values would be a, b, c. 
Typescript protects us from such an error by typing k as a string.

Type assertion is exactly for such cases - when the programmer has additional knowledge. 
if you know that obj doesn't have extra properties you can use literal type assertion.
*/



//https://github.com/sindresorhus/ts-extras/blob/main/source/object-keys.ts