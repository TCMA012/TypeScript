/*
https://stackoverflow.com/questions/38906359/create-a-global-variable-in-typescript

globalThis is the future.

First, TypeScript files have two kinds of scopes

global scope
If your file hasn't any import or export line, this file would be executed in global scope that all declaration in it are visible outside this file.

So we would create global variables like this:
*/
// xx.d.ts
declare var age: number

// or 
// xx.ts
// with or without declare keyword
var age: number

// other.ts
globalThis.age = 18 // no error
/*
All magic come from var. Replace var with let or const won't work.

module scope
If your file has any import or export line, this file would be executed within its own scope that we need to 
extend global by declaration-merging.
*/
// xx[.d].ts
declare global {
  var age: number;
}

// other.ts
globalThis.age = 18 // no error