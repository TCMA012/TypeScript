/*
interface with computed keys
https://stackoverflow.com/questions/69635410/can-i-define-a-typescript-interface-with-computed-keys/69635643#69635643

use 
as const
 to make a nonwidening string literal type at the key declarations:
*/
const NAMESPACE = 'com.pizza'

const KEY_SAUCE = `${NAMESPACE}/sauce` as const;
const KEY_CRUST = `${NAMESPACE}/crust` as const;

type Sauce = number;
type Crust = string;

interface PizzaToken {
    radius: number
    [KEY_SAUCE]: Sauce
    [KEY_CRUST]: Crust
}