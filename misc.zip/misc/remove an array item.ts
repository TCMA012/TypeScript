//remove an array item
let key: any
let myArray = []

delete myArray[key];
/*
this sets the element to undefined.
Better to use the Array.prototype.splice function:
*/
const index = myArray.indexOf(key, 0);
if (index > -1) {
   myArray.splice(index, 1);
}